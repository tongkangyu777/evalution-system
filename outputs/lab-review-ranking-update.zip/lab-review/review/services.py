from collections import Counter
from decimal import Decimal

from django.contrib.auth.hashers import make_password
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from .forms import normalized_key, paper_key
from .models import (
    Affair, Attendance, Audit, Batch, Grant, InputCheck, Member, Paper, PeerTotal,
    RuleVersion, Settlement, SubmissionState, TeacherScore, Term,
)
from .scoring import AWARDS, DEFAULT_RULE, GRADES, award_groups, evaluate, group_peer_display, rank_rows


class RuleError(Exception):
    pass


def audit(term, actor, action, **details):
    Audit.objects.create(term=term, actor=actor, action=action, details=details)


def lock_term(pk):
    return Term.objects.select_for_update().get(pk=pk)


def persist_deadline(term):
    if term.state == Term.State.OPEN and term.deadline_passed:
        term.state = Term.State.CLOSED
        term.save(update_fields=["state"])
        audit(term, None, "到期截止", submitted=term.submitted_count, missing=term.members.count() - term.submitted_count)


def editable_records(term):
    persist_deadline(term)
    if not term.records_editable:
        raise RuleError("请由审核人退回当前结算后再修改录入记录。")


@transaction.atomic
def create_term(actor, fields, source=None):
    if Term.objects.filter(slug=fields["slug"]).exists():
        raise RuleError("学期标识已被使用。")
    term = Term.objects.create(title=fields["title"], slug=fields["slug"],
                               shared_hash=make_password(fields["password"]))
    term.rule = RuleVersion.objects.create(
        term=term, number=1, settings=source.rule.settings if source else DEFAULT_RULE,
        editor=actor, reason="复制往期规则" if source else "初始化评分细则",
    )
    term.save(update_fields=["rule"])
    if source:
        Grant.objects.bulk_create([
            Grant(term=term, user_id=grant.user_id, role=grant.role) for grant in source.grants.all()
        ])
        Member.objects.bulk_create([
            Member(term=term, name=member.name, login_name=member.login_name, login_key=member.login_key)
            for member in source.members.all()
        ])
    audit(term, actor, "创建学期", source=source.slug if source else "")
    return term


@transaction.atomic
def change_rule(term_id, actor, rule, reason):
    term = lock_term(term_id)
    if term.state != Term.State.DRAFT:
        raise RuleError("互评开启后，当前学期的规则已经锁定。")
    old = term.rule
    if old.settings == rule:
        return old
    term.rule = RuleVersion.objects.create(term=term, number=old.number + 1, settings=rule, editor=actor, reason=reason)
    term.save(update_fields=["rule"])
    audit(term, actor, "变更评分规则", previous=old.number, version=term.rule.number, reason=reason,
          before=old.settings, after=rule)
    return term.rule


@transaction.atomic
def open_term(term_id, actor, closes_at):
    term = lock_term(term_id)
    if term.state != Term.State.DRAFT:
        raise RuleError("只有准备中的学期可以开启互评。")
    members = list(term.members.values_list("pk", flat=True))
    if len(members) < 2 or len(members) > 500:
        raise RuleError("开启互评需要 2–500 名参评学生。")
    if set(term.grants.values_list("role", flat=True)) != set(Grant.Role.values):
        raise RuleError("请先配齐管理员、两位教师和审核人。")
    if closes_at and closes_at <= timezone.now():
        raise RuleError("计划截止时间须在未来。")
    SubmissionState.objects.bulk_create([SubmissionState(member_id=pk) for pk in members])
    PeerTotal.objects.bulk_create([PeerTotal(member_id=pk) for pk in members])
    term.closes_at = closes_at
    term.state = Term.State.OPEN
    term.save(update_fields=["closes_at", "state"])
    audit(term, actor, "开启互评", version=term.rule.number, members=len(members),
          closes_at=closes_at.isoformat() if closes_at else "")


@transaction.atomic
def close_term(term_id, actor, reason):
    term = lock_term(term_id)
    persist_deadline(term)
    if term.state == Term.State.CLOSED:
        return
    if term.state != Term.State.OPEN:
        raise RuleError("只有开放中的学期可以截止。")
    term.state = Term.State.CLOSED
    term.save(update_fields=["state"])
    audit(term, actor, "手动截止", reason=reason, submitted=term.submitted_count,
          missing=term.members.count() - term.submitted_count)


@transaction.atomic
def rotate_pass(term_id, actor, password, reason):
    term = lock_term(term_id)
    term.shared_hash = make_password(password)
    term.pass_version += 1
    term.save(update_fields=["shared_hash", "pass_version"])
    audit(term, actor, "轮换统一口令", reason=reason)


def validate_ballot(member_ids, choices):
    if set(choices) != {f"grade_{pk}" for pk in member_ids}:
        raise RuleError("请为名单上的每个人（含本人）选择一个等级。")
    if any(len(values) != 1 or values[0] not in GRADES for values in choices.values()):
        raise RuleError("每个人仅能选择一个有效的 A、B、C 或 D 等级。")
    by_member = {pk: choices[f"grade_{pk}"][0] for pk in member_ids}
    counts = Counter(by_member.values())
    if counts["A"] > 3 or counts["B"] > 3:
        raise RuleError("A 和 B 各最多选择 3 人，自评占用所在等级的名额。")
    return by_member


@transaction.atomic
def submit_ballot(term_id, member_id, pass_version, choices):
    term = lock_term(term_id)
    if term.pass_version != pass_version:
        raise RuleError("统一口令已轮换，请重新登录。")
    state = SubmissionState.objects.get(member_id=member_id, member__term=term)
    if state.submitted:
        return False
    if not term.accepts_ballots:
        raise RuleError("本学期互评已截止。")
    totals = list(PeerTotal.objects.filter(member__term=term).order_by("member_id"))
    grades = validate_ballot([row.member_id for row in totals], choices)
    updates = []
    for row in totals:
        if row.member_id != member_id:
            field = grades[row.member_id].lower()
            setattr(row, field, getattr(row, field) + 1)
            updates.append(row)
    PeerTotal.objects.bulk_update(updates, ["a", "b", "c", "d"])
    state.submitted = True
    state.save(update_fields=["submitted"])
    term.submitted_count += 1
    term.save(update_fields=["submitted_count"])
    if term.submitted_count % 5 == 0:
        pooled = PeerTotal.objects.filter(member__term=term).aggregate(
            **{f"count_{grade}": Sum(grade.lower()) for grade in GRADES}
        )
        display = group_peer_display({grade: pooled[f"count_{grade}"] for grade in GRADES},
                                     term.rule.settings["caps"]["peer"])
        Batch.objects.create(term=term, number=term.submitted_count // 5,
                             submitted_count=term.submitted_count, display=display)
    return True


def log_record(term, actor, action, member, **details):
    audit(term, actor, action, member=member.pk, **details)


def record_attendance(member, data, actor):
    record, created = Attendance.objects.get_or_create(member=member, defaults=data)
    if created or record.score != data["score"] or record.evidence != data["evidence"]:
        if not created:
            record.score = data["score"]
            record.evidence = data["evidence"]
            record.save(update_fields=["score", "evidence"])
        log_record(member.term, actor, "录入考勤", member)
        return True
    return False


def record_affair(member, data, actor):
    reference_key = normalized_key(data["reference"])
    if member.affairs.filter(reference_key=reference_key).exists():
        raise RuleError("该学生的同一事项已登记。")
    if data["kind"] in (Affair.Kind.LEADER, Affair.Kind.PURCHASE) and member.affairs.filter(kind=data["kind"]).exists():
        raise RuleError("Leader 和采购报销各自每学期最多计一次。")
    Affair.objects.create(member=member, reference_key=reference_key, **data)
    mark_check(member, "affairs_checked", False)
    log_record(member.term, actor, "录入公共事务", member)


def record_paper(member, data, actor):
    key = paper_key(data["identifier"])
    special = data["position"] == "special"
    position = None if special else int(data["position"])
    current = member.papers.filter(identifier_key=key).first()
    if current:
        if current.published_on == data["published_on"] and current.evidence == data["evidence"] and (
            current.special if special else (not current.special and current.position == position)
        ):
            return False
        raise RuleError("该学生的同一论文已登记。如需修改，请先删除旧记录。")
    Paper.objects.create(member=member, identifier=data["identifier"], identifier_key=key,
                         published_on=data["published_on"], evidence=data["evidence"], special=special, position=position)
    mark_check(member, "papers_checked", False)
    log_record(member.term, actor, "录入论文", member)
    return True


def mark_check(member, field, value):
    check, _ = InputCheck.objects.get_or_create(member=member)
    if getattr(check, field) != value:
        setattr(check, field, value)
        check.save(update_fields=[field])


def readiness(term):
    members = list(term.members.select_related("attendance", "peer", "input_check")
                   .prefetch_related("teacher_scores", "affairs", "papers"))
    rows, issues = [], []
    rule = term.rule.settings
    for member in members:
        scores = {entry.slot: entry for entry in member.teacher_scores.all()}
        votes = {grade: getattr(member.peer, grade.lower()) for grade in GRADES}
        attendance = getattr(member, "attendance", None)
        check = getattr(member, "input_check", None)
        affairs = list(member.affairs.all())
        papers = list(member.papers.all())
        missing = []
        if set(scores) != {"wu", "liu"}:
            missing.append("教师分未齐")
        if not sum(votes.values()):
            missing.append("无有效他评票，待核实")
        if attendance is None or not 0 <= attendance.score <= Decimal(rule["caps"]["attendance"]):
            missing.append("考勤未录入或超限")
        if not check or not check.affairs_checked:
            missing.append("公共事务未核实")
        if not check or not check.papers_checked:
            missing.append("论文未核实")
        if any(paper.position is None for paper in papers):
            missing.append("特殊作者排序待导师认定")
        if missing:
            issues.append(f"{member.label}：{'、'.join(missing)}")
            continue
        source = {
            "teacher_scores": {slot: str(entry.score) for slot, entry in scores.items()},
            "votes": votes,
            "attendance": str(attendance.score),
            "affairs": [entry.kind for entry in affairs],
            "paper_positions": [entry.position for entry in papers],
        }
        rows.append({
            "id": member.pk, "name": member.label, **evaluate(rule, source), "source": source,
            "proof": {
                "teacher_notes": {slot: entry.note for slot, entry in scores.items()},
                "attendance": attendance.evidence,
                "affairs": [{"reference": entry.reference, "evidence": entry.evidence} for entry in affairs],
                "papers": [{"identifier": entry.identifier, "published_on": entry.published_on.isoformat(),
                            "evidence": entry.evidence, "position": entry.position, "decision": entry.decision,
                            "decided_by": entry.decided_by_id} for entry in papers],
            },
        })
    return rows, issues


@transaction.atomic
def prepare_settlement(term_id, actor):
    term = lock_term(term_id)
    persist_deadline(term)
    if term.state != Term.State.CLOSED:
        raise RuleError("请在互评截止后发起正式结算。若已进入审核或公示，请由审核人先退回。")
    rows, issues = readiness(term)
    if issues:
        return None, issues
    previous = term.settlements.order_by("-number").first()
    run = Settlement.objects.create(term=term, rule=term.rule, number=previous.number + 1 if previous else 1,
                                    detail=rank_rows(rows))
    term.state = Term.State.REVIEW
    term.save(update_fields=["state"])
    audit(term, actor, "发起结算", settlement=run.number, rule=term.rule.number)
    return run, []


@transaction.atomic
def return_for_correction(term_id, actor, reason):
    term = lock_term(term_id)
    if term.state not in (Term.State.REVIEW, Term.State.PUBLISHED):
        raise RuleError("当前没有可退回的结算。")
    term.state = Term.State.CLOSED
    term.save(update_fields=["state"])
    audit(term, actor, "退回补录或更正", reason=reason)


@transaction.atomic
def publish(term_id, actor, settlement_number, choices):
    term = lock_term(term_id)
    run = term.settlements.order_by("-number").first()
    if term.state != Term.State.REVIEW or run is None or run.number != settlement_number:
        raise RuleError("当前结算版本已变化，请重新审核。")
    winners, reasons = {}, {}
    for rank, group in award_groups(run.detail).items():
        if len(group) == 1:
            winners[group[0]["id"]] = AWARDS[rank]
        if len(group) > 1:
            selected, reason = choices.get(rank, ("", ""))
            if selected not in {str(row["id"]) for row in group} or not 1 <= len(reason) <= 300:
                raise RuleError(f"第 {rank} 名仍并列，请选定该奖项获得者并填写处理依据。")
            winners[int(selected)] = AWARDS[rank]
            reasons[str(rank)] = {"member": int(selected), "reason": reason}
    run.public = [
        {"name": row["name"], "rank": row["rank"], "total": row["total"],
         "award": winners[row["id"]][0] if row["id"] in winners else "",
         "amount": winners[row["id"]][1] if row["id"] in winners else None}
        for row in run.detail
    ]
    run.published_at = timezone.now()
    run.save(update_fields=["public", "published_at"])
    term.state = Term.State.PUBLISHED
    term.save(update_fields=["state"])
    audit(term, actor, "发布综合成绩和获奖名单", settlement=run.number, tied_awards=reasons)
    return run
