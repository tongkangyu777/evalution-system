from django.conf import settings as django_settings
from django.db import models
from django.db.models import Q
from django.utils import timezone


class Term(models.Model):
    class State(models.TextChoices):
        DRAFT = "draft", "准备中"
        OPEN = "open", "互评开放"
        CLOSED = "closed", "互评截止"
        REVIEW = "review", "结算审核"
        PUBLISHED = "published", "已公示"

    title = models.CharField(max_length=80)
    slug = models.SlugField(max_length=60, unique=True)
    state = models.CharField(max_length=12, choices=State, default=State.DRAFT)
    closes_at = models.DateTimeField(null=True, blank=True)
    rule = models.ForeignKey("RuleVersion", null=True, on_delete=models.PROTECT, related_name="+")
    shared_hash = models.CharField(max_length=160)
    pass_version = models.PositiveIntegerField(default=1)
    submitted_count = models.PositiveIntegerField(default=0)

    @property
    def deadline_passed(self):
        return self.closes_at is not None and timezone.now() >= self.closes_at

    @property
    def accepts_ballots(self):
        return self.state == self.State.OPEN and not self.deadline_passed

    @property
    def records_editable(self):
        return self.state in (self.State.DRAFT, self.State.OPEN, self.State.CLOSED)

    @property
    def display_state(self):
        if self.state == self.State.OPEN and self.deadline_passed:
            return self.State.CLOSED.label
        return self.get_state_display()


class RuleVersion(models.Model):
    term = models.ForeignKey(Term, on_delete=models.CASCADE, related_name="versions")
    number = models.PositiveIntegerField()
    settings = models.JSONField()
    reason = models.CharField(max_length=300)
    editor = models.ForeignKey(django_settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["term", "number"], name="unique_rule_version")]


class Grant(models.Model):
    class Role(models.TextChoices):
        MANAGER = "manager", "学生管理员"
        TEACHER_WU = "wu", "吴敏老师"
        TEACHER_LIU = "liu", "刘馨刚老师"
        REVIEWER = "reviewer", "结算审核人"

    term = models.ForeignKey(Term, on_delete=models.CASCADE, related_name="grants")
    user = models.ForeignKey(django_settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="term_grants")
    role = models.CharField(max_length=12, choices=Role)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["term", "user"], name="one_role_per_term"),
            models.UniqueConstraint(fields=["term", "role"], name="one_account_per_role"),
        ]


class StaffProfile(models.Model):
    user = models.OneToOneField(django_settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    must_change_password = models.BooleanField(default=True)


class Member(models.Model):
    term = models.ForeignKey(Term, on_delete=models.CASCADE, related_name="members")
    name = models.CharField(max_length=60)
    login_name = models.CharField(max_length=60)
    login_key = models.CharField(max_length=100)

    @property
    def label(self):
        return self.name if self.name == self.login_name else f"{self.name}（{self.login_name}）"

    class Meta:
        constraints = [models.UniqueConstraint(fields=["term", "login_key"], name="unique_login_in_term")]
        ordering = ["pk"]


class SubmissionState(models.Model):
    member = models.OneToOneField(Member, on_delete=models.CASCADE, primary_key=True, related_name="submission")
    submitted = models.BooleanField(default=False)

    class Meta:
        db_table = "identity_submission_state"


class PeerTotal(models.Model):
    member = models.OneToOneField(Member, on_delete=models.CASCADE, primary_key=True, related_name="peer")
    a = models.PositiveIntegerField(default=0)
    b = models.PositiveIntegerField(default=0)
    c = models.PositiveIntegerField(default=0)
    d = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "anonymous_peer_totals"


class Batch(models.Model):
    term = models.ForeignKey(Term, on_delete=models.CASCADE, related_name="batches")
    number = models.PositiveIntegerField()
    submitted_count = models.PositiveIntegerField()
    display = models.JSONField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=["term", "number"], name="unique_batch_per_term")]


class TeacherScore(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE, related_name="teacher_scores")
    slot = models.CharField(max_length=3, choices=[("wu", "吴敏"), ("liu", "刘馨刚")])
    score = models.DecimalField(max_digits=4, decimal_places=2)
    note = models.CharField(max_length=500, blank=True)

    class Meta:
        db_table = "confidential_teacher_scores"
        constraints = [
            models.UniqueConstraint(fields=["member", "slot"], name="unique_teacher_score"),
            models.CheckConstraint(condition=Q(score__gte=0, score__lte=25), name="teacher_score_in_range"),
        ]


class Attendance(models.Model):
    member = models.OneToOneField(Member, on_delete=models.CASCADE, related_name="attendance")
    score = models.DecimalField(max_digits=11, decimal_places=6)
    evidence = models.CharField(max_length=500)


class Affair(models.Model):
    class Kind(models.TextChoices):
        LEADER = "leader", "实验室 Leader（安全及卫生）"
        PURCHASE = "purchase", "公共试剂、耗材采购及报销"
        ACTIVITY = "activity", "其他事务（接待、科普、活动组织等）"

    member = models.ForeignKey(Member, on_delete=models.CASCADE, related_name="affairs")
    kind = models.CharField(max_length=10, choices=Kind)
    reference = models.CharField(max_length=160)
    reference_key = models.CharField(max_length=320)
    evidence = models.CharField(max_length=500)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["member", "reference_key"], name="unique_matter_per_member"),
            models.UniqueConstraint(fields=["member", "kind"],
                                    condition=Q(kind__in=["leader", "purchase"]), name="once_per_term_affair"),
        ]


class Paper(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE, related_name="papers")
    identifier = models.CharField(max_length=180)
    identifier_key = models.CharField(max_length=360)
    published_on = models.DateField()
    evidence = models.CharField(max_length=500)
    special = models.BooleanField(default=False)
    position = models.PositiveSmallIntegerField(null=True)
    decision = models.CharField(max_length=500, blank=True)
    decided_by = models.ForeignKey(django_settings.AUTH_USER_MODEL, null=True, on_delete=models.PROTECT)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["member", "identifier_key"], name="unique_paper_per_member"),
            models.CheckConstraint(condition=Q(position__in=[0, 1, 2, 3]) | Q(position__isnull=True),
                                   name="paper_position_in_range"),
        ]


class InputCheck(models.Model):
    member = models.OneToOneField(Member, on_delete=models.CASCADE, related_name="input_check")
    affairs_checked = models.BooleanField(default=False)
    papers_checked = models.BooleanField(default=False)


class Audit(models.Model):
    term = models.ForeignKey(Term, on_delete=models.CASCADE, related_name="audits")
    actor = models.ForeignKey(django_settings.AUTH_USER_MODEL, null=True, on_delete=models.PROTECT)
    action = models.CharField(max_length=60)
    details = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)


class Settlement(models.Model):
    term = models.ForeignKey(Term, on_delete=models.CASCADE, related_name="settlements")
    rule = models.ForeignKey(RuleVersion, on_delete=models.PROTECT)
    number = models.PositiveIntegerField()
    detail = models.JSONField()
    public = models.JSONField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    published_at = models.DateTimeField(null=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["term", "number"], name="unique_settlement_version")]


class LoginAttempt(models.Model):
    key = models.CharField(max_length=64, primary_key=True)
    count = models.PositiveIntegerField(default=0)
    expires_at = models.DateTimeField(db_index=True)
