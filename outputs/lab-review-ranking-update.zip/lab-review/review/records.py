import secrets
import time

from django import forms
from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods

from .forms import (
    AffairForm, AttendanceForm, CheckForm, CSVForm, PaperForm, normalized_key, paper_key, read_csv,
)
from .models import Member, Term
from .security import term_permission
from .services import (
    RuleError, audit, editable_records, lock_term, log_record, mark_check, record_affair,
    record_attendance, record_paper,
)
from .staff import MANAGER


class MemberForm(forms.Form):
    name = forms.CharField(label="姓名", max_length=60)
    login_name = forms.CharField(label="登录名（同名时填写）", max_length=60, required=False)

    def clean(self):
        cleaned = super().clean()
        if "name" in cleaned:
            cleaned["login_name"] = cleaned.get("login_name") or cleaned["name"]
            key = normalized_key(cleaned["login_name"])
            if not 0 < len(key) <= 100:
                raise forms.ValidationError("登录名无效。")
            cleaned["login_key"] = key
        return cleaned


IMPORTS = {
    "roster": ("参评名单", ("姓名",), ("登录名",), "姓名,登录名\n示例学生,示例学生"),
    "attendance": ("考勤分数", ("登录名", "考勤分", "核定依据"), (),
                   "登录名,考勤分,核定依据\n示例学生,9,学期考勤表第 3 行"),
    "papers": ("论文成果", ("登录名", "论文标识", "发表日期", "作者顺位", "论文证明"), (),
               "登录名,论文标识,发表日期,作者顺位,论文证明\n示例学生,10.0000/example,2026-10-15,2,正式发表页"),
}


@term_permission(MANAGER)
@require_http_methods(["GET", "POST"])
def roster(request, term, grant):
    form = MemberForm(request.POST if request.method == "POST" else None)
    if request.method == "POST":
        try:
            with transaction.atomic():
                locked = lock_term(term.pk)
                if locked.state != Term.State.DRAFT:
                    raise RuleError("名单已锁定。")
                if request.POST.get("action") == "remove":
                    raw_id = request.POST.get("member", "")
                    member = get_object_or_404(locked.members, pk=int(raw_id)
                                               if raw_id.isdecimal() and len(raw_id) <= 18 else 0)
                    audit(locked, request.user, "移除参评成员", name=member.label)
                    member.delete()
                elif form.is_valid():
                    if locked.members.count() >= 500:
                        raise RuleError("每学期最多 500 名参评学生。")
                    if locked.members.filter(login_key=form.cleaned_data["login_key"]).exists():
                        raise RuleError("登录名重复，请为同名成员设置可区分的登录名。")
                    member = locked.members.create(**form.cleaned_data)
                    log_record(locked, request.user, "添加参评成员", member)
                else:
                    return render(request, "review/roster.html", {"term": term, "form": form})
        except RuleError as exc:
            form.add_error(None, str(exc))
        else:
            messages.success(request, "名单已更新。")
            return redirect("roster", slug=term.slug)
    return render(request, "review/roster.html", {"term": term, "form": form})


def check_import_stage(term, kind):
    if kind == "roster":
        if term.state != Term.State.DRAFT:
            raise RuleError("名单已经锁定。")
    elif not term.records_editable:
        raise RuleError("请由审核人退回当前结算后再导入。")


def validate_import(term, kind, raw):
    _, columns, optional, _ = IMPORTS[kind]
    members = {member.login_key: member for member in term.members.all()}
    errors, clean, seen = [], [], set()
    for line, row in read_csv(raw, columns, optional=optional):
        try:
            data, member, key, label, skip = import_row(term, kind, row, members)
            if key in seen:
                raise RuleError("本次文件包含重复记录。")
            seen.add(key)
            clean.append((data, member, label, skip))
        except RuleError as exc:
            errors.append(f"第 {line} 行：{exc}")
    if kind == "roster" and len(members) + sum(not row[-1] for row in clean) > 500:
        errors.append("导入后的学生人数不得超过 500 人。")
    return clean, errors


def import_row(term, kind, row, members):
    if kind == "roster":
        form = MemberForm({"name": row["姓名"], "login_name": row.get("登录名", "")})
    elif kind == "attendance":
        form = AttendanceForm({"score": row["考勤分"], "evidence": row["核定依据"]},
                              cap=term.rule.settings["caps"]["attendance"])
    else:
        form = PaperForm({
            "identifier": row["论文标识"], "published_on": row["发表日期"], "position": row["作者顺位"],
            "evidence": row["论文证明"],
        })
    if not form.is_valid():
        errors = [f"{form.fields[key].label if key in form.fields else ''} {error}"
                  for key, details in form.errors.items() for error in details]
        raise RuleError("；".join(errors))
    data = form.cleaned_data
    if kind == "roster":
        key = data["login_key"]
        current = members.get(key)
        if current and (current.name != data["name"] or current.login_name != data["login_name"]):
            raise RuleError("登录名已存在且对应不同成员。")
        return data, None, key, data["name"] + " / " + data["login_name"], bool(current)
    member = members.get(normalized_key(row["登录名"]))
    if not member:
        raise RuleError("登录名不在本学期名单中。")
    if kind == "attendance":
        current = getattr(member, "attendance", None)
        skip = current and current.score == data["score"] and current.evidence == data["evidence"]
        return data, member, member.pk, f"{member.label} / {data['score']} 分", bool(skip)
    key = paper_key(data["identifier"])
    current = member.papers.filter(identifier_key=key).first()
    if current:
        special = data["position"] == "special"
        same_position = current.special if special else not current.special and current.position == int(data["position"])
        if not (same_position and current.evidence == data["evidence"] and current.published_on == data["published_on"]):
            raise RuleError("同一论文已登记，原记录与导入内容不同。")
    return data, member, (member.pk, key), f"{member.label} / {data['identifier']}", bool(current)


@transaction.atomic
def apply_import(term_id, kind, raw, actor):
    term = lock_term(term_id)
    check_import_stage(term, kind)
    if kind != "roster":
        editable_records(term)
    rows, errors = validate_import(term, kind, raw)
    if errors:
        return 0, errors
    changed = 0
    for data, member, _, skip in rows:
        if skip:
            continue
        if kind == "roster":
            term.members.create(**data)
        elif kind == "attendance":
            record_attendance(member, data, actor)
        else:
            record_paper(member, data, actor)
        changed += 1
    if changed:
        audit(term, actor, "确认批量导入", kind=kind, count=changed)
    return changed, []


@term_permission(MANAGER)
@require_http_methods(["GET", "POST"])
def csv_import(request, term, grant, kind):
    if kind not in IMPORTS:
        return render(request, "review/error.html", {"title": "导入类型不存在"}, status=404)
    label, _, _, sample = IMPORTS[kind]
    form = CSVForm(request.POST, request.FILES) if request.method == "POST" else CSVForm()
    preview, errors, token = [], [], ""
    if request.method == "POST":
        try:
            check_import_stage(term, kind)
            if request.POST.get("action") == "confirm":
                pending = request.session.pop("pending_import", {})
                expected = (term.pk, kind, request.POST.get("token"))
                if ((pending.get("term"), pending.get("kind"), pending.get("token")) != expected
                        or pending.get("expires", 0) <= time.time()):
                    raise RuleError("预览已失效，请重新导入并检查。")
                changed, errors = apply_import(term.pk, kind, pending["raw"], request.user)
                if not errors:
                    messages.success(request, f"已处理 {changed} 条记录，内容相同的记录已跳过。")
                    return redirect("roster" if kind == "roster" else "records", slug=term.slug)
                form = CSVForm()
            elif form.is_valid():
                raw = form.cleaned_data["data"]
                preview, errors = validate_import(term, kind, raw)
                if not errors:
                    token = secrets.token_urlsafe(24)
                    request.session["pending_import"] = {
                        "term": term.pk, "kind": kind, "raw": raw, "token": token, "expires": time.time() + 600,
                    }
        except (RuleError, ValueError) as exc:
            errors = [str(exc)]
    return render(request, "review/import.html", {
        "term": term, "form": form, "kind": kind, "label": label, "sample": sample,
        "preview": [(item_label, skip) for _, _, item_label, skip in preview],
        "errors": errors, "token": token,
    })


@term_permission(MANAGER)
def records(request, term, grant):
    members = term.members.select_related("attendance", "input_check")
    return render(request, "review/records.html", {"term": term, "members": members})


def record_forms(term, member):
    attendance = getattr(member, "attendance", None)
    check = getattr(member, "input_check", None)
    return {
        "attendance": AttendanceForm(
            cap=term.rule.settings["caps"]["attendance"],
            auto_id="id_attendance_%s",
            initial={"score": attendance.score, "evidence": attendance.evidence} if attendance else None,
        ),
        "affair": AffairForm(auto_id="id_affair_%s"),
        "paper": PaperForm(auto_id="id_paper_%s"),
        "check": CheckForm(initial={
            "affairs_checked": check.affairs_checked, "papers_checked": check.papers_checked,
        } if check else None),
    }


@term_permission(MANAGER)
@require_http_methods(["GET", "POST"])
def record_item(request, term, grant, member_id):
    member = get_object_or_404(term.members, pk=member_id)
    forms_by_kind = record_forms(term, member)
    action = request.POST.get("action", "")
    if request.method == "POST":
        try:
            with transaction.atomic():
                locked = lock_term(term.pk)
                editable_records(locked)
                if action in ("delete_affair", "delete_paper"):
                    collection, flag = (member.affairs, "affairs_checked") if action == "delete_affair" else (
                        member.papers, "papers_checked")
                    entry_id = request.POST.get("entry", "")
                    entry = get_object_or_404(collection, pk=int(entry_id)
                                              if entry_id.isdecimal() and len(entry_id) <= 18 else 0)
                    log_record(locked, request.user, "删除核定记录", member, kind=action, entry=entry.pk)
                    entry.delete()
                    mark_check(member, flag, False)
                elif action in forms_by_kind:
                    form = forms_by_kind[action]
                    options = {"auto_id": form.auto_id}
                    if action == "attendance":
                        options["cap"] = locked.rule.settings["caps"]["attendance"]
                    form = type(form)(request.POST, **options)
                    forms_by_kind[action] = form
                    if form.is_valid():
                        data = form.cleaned_data
                        if action == "check":
                            if data["papers_checked"] and member.papers.filter(position__isnull=True).exists():
                                raise RuleError("存在待导师认定的论文，暂不能确认论文核实完成。")
                            for field, value in data.items():
                                mark_check(member, field, value)
                            log_record(locked, request.user, "更新核实状态", member, **data)
                        else:
                            operation = {"attendance": record_attendance, "affair": record_affair,
                                         "paper": record_paper}[action]
                            operation(member, data, request.user)
                    else:
                        raise RuleError("请检查表单中的提示。")
                else:
                    raise RuleError("未识别的操作。")
        except RuleError as exc:
            messages.error(request, str(exc))
        else:
            messages.success(request, "已保存。")
            return redirect("record_item", slug=term.slug, member_id=member.pk)
    return render(request, "review/record.html", {
        "term": term, "member": member, **forms_by_kind,
        "affairs": member.affairs.all(), "papers": member.papers.all(),
        "editable": term.records_editable,
    })
