import csv
import io
import unicodedata
from decimal import Decimal

from django import forms

from .models import Affair


CATEGORIES = {
    "teacher": "导师评价",
    "peer": "学生匿名互评",
    "attendance": "考勤表现",
    "affairs": "公共事务",
}
POSITIONS = [("1", "第一作者"), ("2", "第二作者"), ("3", "第三作者")]


def normalized_key(value):
    return " ".join(unicodedata.normalize("NFKC", value).split()).casefold()


def decimal_string(value):
    return format(value.normalize(), "f") if value else "0"


def paper_key(value):
    key = normalized_key(value)
    for prefix in ("https://doi.org/", "http://doi.org/", "https://dx.doi.org/", "doi:"):
        if key.startswith(prefix):
            return key.removeprefix(prefix).strip()
    return key


def read_csv(data, columns, *, optional=(), limit=500):
    try:
        reader = csv.DictReader(io.StringIO(data, newline=""), strict=True)
        headers = reader.fieldnames
        if not headers:
            raise ValueError("请包含表头和至少一条记录。")
        headers = [header.lstrip("\ufeff").strip() for header in headers]
        reader.fieldnames = headers
        if not set(columns).issubset(headers) or len(headers) != len(set(headers)):
            raise ValueError("请使用表头 " + "、".join(columns) + "。")
        if set(headers) - set(columns) - set(optional):
            raise ValueError("CSV 包含未识别的列。")
        rows = []
        for record in reader:
            line = reader.line_num
            if None in record or any(value is None for value in record.values()):
                raise ValueError(f"第 {line} 行的列数不一致。")
            if any(value.strip() for value in record.values()):
                rows.append((line, {key: value.strip() for key, value in record.items()}))
            if len(rows) > limit:
                raise ValueError(f"一次最多导入 {limit} 条记录。")
        if not rows:
            raise ValueError("没有可导入的数据。")
        return rows
    except csv.Error as exc:
        raise ValueError("CSV 格式有误，请检查引号和分隔符。") from exc


def password_field(label="统一口令"):
    return forms.CharField(label=label, min_length=10, max_length=128, strip=False, widget=forms.PasswordInput)


def evidence_field(label="核定依据"):
    return forms.CharField(label=label, max_length=500, widget=forms.Textarea(attrs={"rows": 2}))


def amount_field(label, *, ceiling=999, places=2, required=True):
    return forms.DecimalField(
        label=label, min_value=0, max_value=ceiling, max_digits=11, decimal_places=places, required=required,
    )


class StudentLoginForm(forms.Form):
    term = forms.ChoiceField(label="学期")
    login_name = forms.CharField(label="姓名／登录名", max_length=60, widget=forms.TextInput(
        attrs={"autocomplete": "username", "placeholder": "请输入名单中的姓名"}))
    password = forms.CharField(label="统一口令", max_length=128, strip=False,
                               widget=forms.PasswordInput(attrs={"autocomplete": "current-password"}))

    def __init__(self, *args, terms, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["term"].choices = [(term.slug, term.title) for term in terms]


class TermForm(forms.Form):
    title = forms.CharField(label="学期名称", max_length=80)
    slug = forms.SlugField(label="学期标识", max_length=60,
                           help_text="使用字母、数字、连字符或下划线，例如 2027-spring。")
    password = password_field()


class OpenForm(forms.Form):
    closes_at = forms.DateTimeField(
        label="计划截止时间（北京时间）", required=False,
        widget=forms.DateTimeInput(format="%Y-%m-%dT%H:%M", attrs={"type": "datetime-local"}),
        help_text="留空时可在管理端手动截止。",
    )
    confirm = forms.BooleanField(label="确认锁定名单与评分规则并开启互评")


class ReasonForm(forms.Form):
    reason = forms.CharField(label="原因", max_length=300)


class RotateForm(ReasonForm):
    password = password_field("新统一口令")


class CSVForm(forms.Form):
    data = forms.CharField(label="CSV 内容", max_length=120_000, required=False,
                           widget=forms.Textarea(attrs={"rows": 8, "spellcheck": "false"}))
    upload = forms.FileField(label="或选择 UTF-8 CSV 文件", required=False)

    def clean(self):
        cleaned = super().clean()
        text, upload = cleaned.get("data"), cleaned.get("upload")
        if bool(text) == bool(upload):
            raise forms.ValidationError("请粘贴 CSV 内容或上传一个 CSV 文件。")
        if upload:
            if upload.size > 120_000:
                raise forms.ValidationError("CSV 文件不得超过 120 KB。")
            try:
                cleaned["data"] = upload.read().decode("utf-8-sig")
            except UnicodeDecodeError as exc:
                raise forms.ValidationError("请将 CSV 另存为 UTF-8 编码后再导入。") from exc
        return cleaned


class RuleForm(ReasonForm):
    mode = forms.ChoiceField(label="分值配置方式", choices=[("caps", "按满分"), ("shares", "按占比")])
    base = amount_field("基础总分（按占比时填写）", required=False)
    wu = amount_field("吴敏老师权重（%）", ceiling=100)
    liu = amount_field("刘馨刚老师权重（%）", ceiling=100)
    leader = amount_field("Leader 每学期分值")
    purchase = amount_field("采购及报销每学期分值")
    activity = amount_field("其他事务每次分值")
    paper1 = amount_field("第一作者每篇分值")
    paper2 = amount_field("第二作者每篇分值")
    paper3 = amount_field("第三作者每篇分值")

    def __init__(self, *args, rule, **kwargs):
        initial = {"mode": rule["mode"], "base": rule["base"], **rule["weights"], **rule["affair_points"]}
        initial.update({f"paper{key}": value for key, value in rule["paper_points"].items()})
        for key in CATEGORIES:
            initial[f"cap_{key}"] = rule["caps"][key]
            if rule["mode"] == "shares":
                initial[f"share_{key}"] = rule["shares"][key]
        super().__init__(*args, initial=initial, **kwargs)
        for key, label in CATEGORIES.items():
            self.fields[f"cap_{key}"] = amount_field(f"{label}满分", places=6, required=False)
            self.fields[f"share_{key}"] = amount_field(f"{label}占比（%）", ceiling=100, required=False)
        self.order_fields([
            "mode", "base", *[f"cap_{key}" for key in CATEGORIES], *[f"share_{key}" for key in CATEGORIES],
            "wu", "liu", "leader", "purchase", "activity", "paper1", "paper2", "paper3", "reason",
        ])

    def clean(self):
        cleaned = super().clean()
        if self.errors:
            return cleaned
        weights = {key: cleaned[key] for key in ("wu", "liu")}
        if sum(weights.values()) != 100:
            raise forms.ValidationError("两位导师的权重之和必须是 100%。")
        mode = cleaned["mode"]
        if mode == "caps":
            caps = {key: cleaned[f"cap_{key}"] for key in CATEGORIES}
            if None in caps.values() or not 0 < sum(caps.values()) <= 999:
                raise forms.ValidationError("请填写四项满分，合计须大于 0 且不超过 999 分。")
            base = sum(caps.values())
            shares = {key: (value * 100 / base).quantize(Decimal("0.0001")) for key, value in caps.items()}
        else:
            base = cleaned["base"]
            shares = {key: cleaned[f"share_{key}"] for key in CATEGORIES}
            if not base or None in shares.values() or sum(shares.values()) != 100:
                raise forms.ValidationError("请填写大于 0 的基础总分和四项占比，占比之和须为 100%。")
            caps = {key: base * share / 100 for key, share in shares.items()}
        cleaned["rule"] = {
            "mode": mode,
            "base": decimal_string(base),
            "caps": {key: decimal_string(value) for key, value in caps.items()},
            "shares": {key: decimal_string(value) for key, value in shares.items()},
            "weights": {key: decimal_string(value) for key, value in weights.items()},
            "affair_points": {key: decimal_string(cleaned[key]) for key in ("leader", "purchase", "activity")},
            "paper_points": {str(key): decimal_string(cleaned[f"paper{key}"]) for key in (1, 2, 3)},
        }
        return cleaned


class AttendanceForm(forms.Form):
    evidence = evidence_field("考勤依据")

    def __init__(self, *args, cap, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["score"] = amount_field(f"考勤分（0–{cap}）", ceiling=Decimal(cap), places=6)
        self.order_fields(["score", "evidence"])


class AffairForm(forms.Form):
    kind = forms.ChoiceField(label="事项类别", choices=Affair.Kind.choices)
    reference = forms.CharField(label="事项标识", max_length=160,
                                help_text="用唯一的编号或日期加事项名识别同一项贡献。")
    evidence = evidence_field()

    def clean_reference(self):
        reference = self.cleaned_data["reference"]
        if not 0 < len(normalized_key(reference)) <= 320:
            raise forms.ValidationError("事项标识无效。")
        return reference


class PaperForm(forms.Form):
    identifier = forms.CharField(label="DOI 或论文唯一标识", max_length=180)
    published_on = forms.DateField(label="发表日期", input_formats=["%Y-%m-%d"],
                                   widget=forms.DateInput(attrs={"type": "date"}))
    position = forms.ChoiceField(label="作者排序", choices=[*POSITIONS, ("special", "共同第一／特殊排序，待导师认定")])
    evidence = evidence_field("论文证明")

    def clean_identifier(self):
        identifier = self.cleaned_data["identifier"]
        if not 0 < len(paper_key(identifier)) <= 360:
            raise forms.ValidationError("论文标识无效。")
        return identifier


class PaperDecisionForm(forms.Form):
    position = forms.ChoiceField(label="导师认定结果", choices=[*POSITIONS, ("0", "不计分")])
    decision = evidence_field("指导教师统一认定的依据")


class TeacherScoreForm(forms.Form):
    score = amount_field("教师原始分", ceiling=25)


class CheckForm(forms.Form):
    affairs_checked = forms.BooleanField(label="公共事务已核实（含确认为零项）", required=False)
    papers_checked = forms.BooleanField(label="论文成果已核实（含确认为零篇）", required=False)
