import csv
from decimal import Decimal

from django.db.models import Prefetch
from django.http import Http404, HttpResponse
from django.shortcuts import render
from django.views.decorators.http import require_safe

from .models import Affair, Grant, Paper, TeacherScore
from .scoring import GRADES, evaluate, group_peer_display, rank_rows
from .security import term_permission


def is_submitted(member):
    state = getattr(member, "submission", None)
    return state is not None and state.submitted


@term_permission(Grant.Role.MANAGER)
@require_safe
def progress(request, term, grant):
    submitted, pending = [], []
    counts = dict.fromkeys(GRADES, 0)
    members = score_members(term).select_related("submission")
    for member in members:
        (submitted if is_submitted(member) else pending).append(member.label)
        totals = getattr(member, "peer", None)
        if totals is not None:
            for grade in GRADES:
                counts[grade] += getattr(totals, grade.lower())
    cap = term.rule.settings["caps"]["peer"]
    return render(request, "review/progress.html", {
        "term": term, "submitted": submitted, "pending": pending, "total": len(submitted) + len(pending),
        "display": group_peer_display(counts, cap), "cap": cap,
        "rows": current_score_rows(term, members), "refresh": term.records_editable,
    })


def score_members(term):
    return term.members.select_related("peer", "attendance", "input_check").prefetch_related(
        Prefetch("teacher_scores", queryset=TeacherScore.objects.only("member_id", "slot", "score")),
        "affairs", "papers",
    )


def current_score_rows(term, members):
    rule = term.rule.settings
    attendance_cap = Decimal(rule["caps"]["attendance"])
    rows = []
    for member in members:
        teacher_scores = {score.slot: score.score for score in member.teacher_scores.all()}
        teachers_ready = set(teacher_scores) == {Grant.Role.TEACHER_WU, Grant.Role.TEACHER_LIU}
        peer = getattr(member, "peer", None)
        votes = {grade: getattr(peer, grade.lower(), 0) for grade in GRADES}
        attendance = getattr(member, "attendance", None)
        attendance_score = attendance.score if attendance is not None else None
        check = getattr(member, "input_check", None)
        affairs = [entry.kind for entry in member.affairs.all()]
        positions = [entry.position for entry in member.papers.all()]
        recognized = [position for position in positions if position is not None]
        affairs_checked = bool(check and check.affairs_checked)
        papers_checked = bool(check and check.papers_checked)
        missing = []
        if not teachers_ready:
            missing.append("导师分未齐")
        if not sum(votes.values()):
            missing.append("互评暂无有效票")
        if attendance is None:
            missing.append("考勤未录入")
        elif not 0 <= attendance_score <= attendance_cap:
            missing.append("考勤超限待核对")
            attendance_score = None
        if not affairs_checked:
            missing.append("公共事务未核实")
        if None in positions:
            missing.append("论文待导师认定")
        elif not papers_checked:
            missing.append("论文未核实")
        source = {
            "teacher_scores": teacher_scores if teachers_ready else {},
            "votes": votes,
            "attendance": attendance_score,
            "affairs": affairs if affairs or affairs_checked else None,
            "paper_positions": recognized if recognized or (papers_checked and None not in positions) else None,
        }
        rows.append({
            "name": member.label,
            **evaluate(rule, source),
            "status": "、".join(missing) or "分项已齐",
        })
    return rank_rows(rows)


@term_permission(Grant.Role.MANAGER)
@require_safe
def current_scores(request, term, grant):
    return render(request, "review/current_scores.html", {
        "term": term, "rows": current_score_rows(term, score_members(term)),
        "refresh": term.records_editable,
    })


def current_scores_export(term):
    for row in current_score_rows(term, score_members(term)):
        yield tuple(row[key] for key in ("rank", "name", "teacher", "peer", "attendance",
                                         "affairs", "papers", "total", "status"))


def progress_export(term):
    for member in term.members.select_related("submission"):
        yield member.name, member.login_name, "已提交" if is_submitted(member) else "未提交"


def attendance_export(term):
    for member in term.members.select_related("attendance"):
        entry = getattr(member, "attendance", None)
        yield member.name, member.login_name, entry.score if entry else None, entry.evidence if entry else None


def affairs_export(term):
    entries = Affair.objects.filter(member__term=term).select_related("member").order_by("member_id", "pk")
    for entry in entries:
        yield entry.member.name, entry.member.login_name, entry.get_kind_display(), entry.reference, entry.evidence


def papers_export(term):
    entries = Paper.objects.filter(member__term=term).select_related("member").order_by("member_id", "pk")
    for entry in entries:
        position = {None: "待导师认定", 0: "认定不计分"}.get(entry.position, entry.position)
        yield (entry.member.name, entry.member.login_name, entry.identifier, entry.published_on,
               position, "是" if entry.special else "否", entry.evidence)


EXPORTS = {
    "scores": (("目前排名", "姓名", "导师评价分", "学生互评分", "考勤分", "公共事务分", "论文加分",
                "目前总分", "分项状态"), current_scores_export),
    "progress": (("姓名", "登录名", "提交状态"), progress_export),
    "attendance": (("姓名", "登录名", "考勤分", "核定依据"), attendance_export),
    "affairs": (("姓名", "登录名", "事项类别", "事项标识", "核定依据"), affairs_export),
    "papers": (("姓名", "登录名", "论文标识", "发表日期", "作者顺位", "特殊排序", "论文证明"), papers_export),
}


def csv_cell(value):
    if isinstance(value, str) and (
        value.startswith(("\t", "\r", "\n"))
        or value.lstrip(" \t\r\n\ufeff").startswith(("=", "+", "-", "@", "＝", "＋", "－", "＠"))
    ):
        return "'" + value
    return value


@term_permission(Grant.Role.MANAGER)
@require_safe
def export_csv(request, term, grant, kind):
    if kind not in EXPORTS:
        raise Http404
    headers, rows = EXPORTS[kind]
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{term.slug}-{kind}.csv"'
    response.write("\ufeff")
    writer = csv.writer(response)
    writer.writerow(headers)
    writer.writerows(tuple(csv_cell(cell) for cell in row) for row in rows(term))
    return response
