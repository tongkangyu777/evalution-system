from django.urls import path

from review import records, reports, staff, teachers, views

urlpatterns = [
    path("", views.student_login, name="student_login"),
    path("student/", views.student_home, name="student_home"),
    path("student/ballot/", views.ballot, name="ballot"),
    path("student/summary/", views.student_summary, name="student_summary"),
    path("student/results/", views.student_results, name="student_results"),
    path("staff/login/", views.staff_login, name="staff_login"),
    path("staff/password/", views.staff_password, name="staff_password"),
    path("staff/", staff.staff_home, name="staff_home"),
    path("staff/<slug:slug>/", staff.term_home, name="term_home"),
    path("staff/<slug:slug>/rename/", staff.term_rename, name="term_rename"),
    path("staff/<slug:slug>/create/", staff.term_create, name="term_create"),
    path("staff/<slug:slug>/rule/", staff.term_rule, name="term_rule"),
    path("staff/<slug:slug>/progress/", reports.progress, name="term_progress"),
    path("staff/<slug:slug>/scores/", reports.current_scores, name="term_current_scores"),
    path("staff/<slug:slug>/export/<slug:kind>/", reports.export_csv, name="term_export"),
    path("staff/<slug:slug>/action/<slug:action>/", staff.term_action, name="term_action"),
    path("staff/<slug:slug>/roster/", records.roster, name="roster"),
    path("staff/<slug:slug>/import/<slug:kind>/", records.csv_import, name="csv_import"),
    path("staff/<slug:slug>/records/", records.records, name="records"),
    path("staff/<slug:slug>/records/<int:member_id>/", records.record_item, name="record_item"),
    path("staff/<slug:slug>/teacher/", teachers.teacher_scores, name="teacher_scores"),
    path("staff/<slug:slug>/teacher/results/", teachers.teacher_results, name="teacher_results"),
    path("staff/<slug:slug>/teacher/paper/<int:paper_id>/", teachers.teacher_paper, name="teacher_paper"),
    path("staff/<slug:slug>/settlement/", staff.settlement_view, name="settlement_view"),
    path("sign-out/", views.sign_out, name="sign_out"),
    path("assets/style.css", views.css, name="style"),
    path("assets/app.js", views.javascript, name="javascript"),
]

handler400 = views.bad_request
handler403 = views.forbidden
handler404 = views.missing
handler500 = views.server_error
