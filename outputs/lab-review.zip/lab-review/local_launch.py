import argparse
import hashlib
import os
import secrets
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA = ROOT / ".runtime"


def prepare_environment():
    DATA.mkdir(exist_ok=True)
    requirements = ROOT / "requirements.txt"
    revision = hashlib.sha256(requirements.read_bytes()).hexdigest()[:12]
    packages = DATA / f"packages-{sys.version_info.major}{sys.version_info.minor}-{revision}"
    marker = packages / ".ready"
    if not marker.exists():
        wheels = ROOT / "wheels"
        source = ["--no-index", "--find-links", str(wheels)] if wheels.is_dir() else []
        install_temp = DATA / "install-temp"
        install_temp.mkdir(exist_ok=True)
        subprocess.run([
            sys.executable, "-c", "import runpy, sys, tempfile; tempfile.tempdir = sys.argv.pop(1); "
            "runpy.run_module('pip', run_name='__main__')", str(install_temp),
            "install", "--disable-pip-version-check", "--no-cache-dir",
            "--target", str(packages), "--upgrade", *source, "-r", str(requirements),
        ], cwd=ROOT, check=True)
        marker.touch()
    sys.path.insert(0, str(packages))
    secret_file = DATA / "session.key"
    try:
        descriptor = os.open(secret_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        pass
    else:
        with os.fdopen(descriptor, "w", encoding="ascii") as stream:
            stream.write(secrets.token_urlsafe(48))
    os.environ.update({
        "DJANGO_SETTINGS_MODULE": "lab_review.settings",
        "LAB_PRODUCTION": "0",
        "LAB_DATA_DIR": str(DATA),
        "LAB_SECRET_KEY": secret_file.read_text(encoding="ascii"),
    })
    os.environ.pop("LAB_DB_HOST", None)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--test", action="store_true")
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        parser.error("Python 3.10 or later is required.")
    if not 1 <= args.port <= 65535:
        parser.error("The port must be between 1 and 65535.")
    prepare_environment()
    import django
    from django.core.management import call_command

    django.setup()
    if args.test:
        if call_command("test", "review", verbosity=2):
            sys.exit(1)
        return
    call_command("migrate", interactive=False, verbosity=0)
    call_command("bootstrap_review", if_needed=True)
    if args.prepare:
        return
    from waitress import create_server
    from lab_review.wsgi import application

    url = f"http://127.0.0.1:{args.port}/staff/login/"
    server = create_server(application, host="127.0.0.1", port=args.port, threads=4,
                           max_request_body_size=512_000, expose_tracebacks=False)
    print(f"评价系统已启动  {url}", flush=True)
    print("保留此窗口可继续使用，关闭窗口可停止。", flush=True)
    if not args.no_browser:
        browser = threading.Timer(0.4, webbrowser.open, args=[url])
        browser.daemon = True
        browser.start()
    try:
        server.run()
    finally:
        server.close()


if __name__ == "__main__":
    main()
