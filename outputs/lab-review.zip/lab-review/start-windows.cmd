@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "LAB_BUNDLED_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%LAB_BUNDLED_PY%" (
  "%LAB_BUNDLED_PY%" local_launch.py %*
) else (
  where py >nul 2>nul
  if errorlevel 1 (
    python local_launch.py %*
  ) else (
    py -3 local_launch.py %*
  )
)
if errorlevel 1 pause
