import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("LAB_DATA_DIR", BASE_DIR / ".runtime"))
PRODUCTION = os.environ.get("LAB_PRODUCTION") == "1"
DEBUG = False
if PRODUCTION:
    SECRET_KEY = os.environ["LAB_SECRET_KEY"]
    ALLOWED_HOSTS = os.environ["LAB_HOSTS"].split(",")
else:
    SECRET_KEY = os.environ.get("LAB_SECRET_KEY", "")
    if not SECRET_KEY:
        raise RuntimeError("请使用启动程序，或先设置 LAB_SECRET_KEY。")
    ALLOWED_HOSTS = ["localhost", "127.0.0.1", "[::1]", "testserver"]

INSTALLED_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "review",
]
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "review.security.ResponsePrivacyMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]
ROOT_URLCONF = "lab_review.urls"
WSGI_APPLICATION = "lab_review.wsgi.application"
TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "DIRS": [],
    "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth",
        "django.contrib.messages.context_processors.messages",
    ]},
}]
if os.environ.get("LAB_DB_HOST"):
    DATABASES = {"default": {
        "ENGINE": "django.db.backends.postgresql",
        "HOST": os.environ["LAB_DB_HOST"],
        "PORT": os.environ.get("LAB_DB_PORT", "5432"),
        "NAME": os.environ.get("LAB_DB_NAME", "lab_review"),
        "USER": os.environ.get("LAB_DB_USER", "lab_review"),
        "PASSWORD": os.environ["LAB_DB_PASSWORD"],
    }}
elif PRODUCTION:
    raise RuntimeError("生产环境须配置 PostgreSQL。")
else:
    DATABASES = {"default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": DATA_DIR / "review.sqlite3",
        "OPTIONS": {"timeout": 20, "transaction_mode": "IMMEDIATE"},
        "TEST": {"NAME": DATA_DIR / "test-review.sqlite3"},
    }}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 12}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]
LANGUAGE_CODE = "zh-hans"
TIME_ZONE = "Asia/Shanghai"
USE_TZ = True
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
SESSION_COOKIE_AGE = 12 * 60 * 60
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
SESSION_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_SECURE = PRODUCTION
CSRF_COOKIE_SECURE = PRODUCTION
CSRF_COOKIE_HTTPONLY = True
CSRF_FAILURE_VIEW = "review.views.csrf_failure"
SECURE_REFERRER_POLICY = "same-origin"
X_FRAME_OPTIONS = "DENY"
SECURE_SSL_REDIRECT = PRODUCTION
SECURE_HSTS_SECONDS = 86400 if PRODUCTION else 0
if PRODUCTION:
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
DATA_UPLOAD_MAX_MEMORY_SIZE = 512_000
DATA_UPLOAD_MAX_NUMBER_FIELDS = 1500
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {"discard": {"class": "logging.NullHandler"}},
    "loggers": {
        "django.request": {"handlers": ["discard"], "propagate": False},
        "django.security": {"handlers": ["discard"], "propagate": False},
        "django.server": {"handlers": ["discard"], "propagate": False},
        "django.db.backends": {"handlers": ["discard"], "propagate": False},
    },
}
