from waitress import serve

from lab_review.wsgi import application

serve(
    application, host="0.0.0.0", port=8080, threads=6,
    trusted_proxy="*", trusted_proxy_count=1,
    trusted_proxy_headers={"x-forwarded-for", "x-forwarded-proto"},
    max_request_body_size=512_000, expose_tracebacks=False,
)
