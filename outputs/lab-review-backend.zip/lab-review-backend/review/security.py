from datetime import timedelta
from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect
from django.utils.crypto import salted_hmac
from django.utils import timezone

from .models import Grant, LoginAttempt, Member, StaffProfile, Term


class ResponsePrivacyMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response.headers.setdefault("Cache-Control", "no-store")
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; object-src 'none'; base-uri 'none'; "
            "frame-ancestors 'none'; form-action 'self'"
        )
        return response


def attempt_key(request, portal):
    # Proxy headers are deliberately excluded. Only failed logins consume quota.
    address = request.META.get("REMOTE_ADDR", "unknown")
    return salted_hmac("lab-login", f"{portal}:{address}", algorithm="sha256").hexdigest()


def login_blocked(key):
    return LoginAttempt.objects.filter(key=key, count__gte=30, expires_at__gt=timezone.now()).exists()


def record_failed_login(key):
    now = timezone.now()
    with transaction.atomic():
        attempt, _ = LoginAttempt.objects.select_for_update().get_or_create(
            key=key, defaults={"expires_at": now + timedelta(minutes=10)}
        )
        if attempt.expires_at <= now:
            attempt.count = 0
            attempt.expires_at = now + timedelta(minutes=10)
        attempt.count += 1
        attempt.save(update_fields=["count", "expires_at"])


def staff_required(view):
    @login_required(login_url="staff_login")
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        profile = StaffProfile.objects.filter(user=request.user).first()
        if profile is None:
            raise PermissionDenied
        if profile.must_change_password:
            return redirect("staff_password")
        return view(request, *args, **kwargs)

    return wrapped


def term_permission(*roles):
    def decorator(view):
        @staff_required
        @wraps(view)
        def wrapped(request, slug, *args, **kwargs):
            grant = get_object_or_404(
                Grant.objects.select_related("term", "term__rule"),
                term__slug=slug, user=request.user, role__in=roles,
            )
            return view(request, grant.term, grant, *args, **kwargs)

        return wrapped

    return decorator


def student_required(view):
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        info = request.session.get("student")
        if not info:
            return redirect("student_login")
        member = Member.objects.select_related("term", "term__rule").filter(
            pk=info["member"], term_id=info["term"], term__pass_version=info["version"],
        ).exclude(term__state=Term.State.DRAFT).first()
        if not member:
            request.session.pop("student", None)
            return redirect("student_login")
        return view(request, member, *args, **kwargs)

    return wrapped
