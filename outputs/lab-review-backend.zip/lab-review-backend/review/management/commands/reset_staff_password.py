import secrets
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from review.models import StaffProfile
from .bootstrap_review import write_private


class Command(BaseCommand):
    help = "由运行环境维护人重置一个工作台账号，生成新的首次登录凭证。"

    def add_arguments(self, parser):
        parser.add_argument("username")
        parser.add_argument("--credentials", type=Path, required=True)

    def handle(self, *args, **options):
        username = options["username"]
        path = options["credentials"]
        if path.exists():
            raise CommandError("请选择尚不存在的凭证输出文件。")
        password = secrets.token_urlsafe(18)
        created_file = False
        try:
            with transaction.atomic():
                profile = StaffProfile.objects.select_for_update().select_related("user").filter(
                    user__username=username).first()
                if not profile:
                    raise CommandError("未找到工作台账号。")
                profile.user.set_password(password)
                profile.user.save(update_fields=["password"])
                profile.must_change_password = True
                profile.save(update_fields=["must_change_password"])
                write_private(path, f"账号  {username}\n临时密码  {password}\n首次登录须修改临时密码。\n")
                created_file = True
        except Exception:
            if created_file:
                path.unlink(missing_ok=True)
            raise
        self.stdout.write("密码已重置。新凭证已写入指定私密文件。")
