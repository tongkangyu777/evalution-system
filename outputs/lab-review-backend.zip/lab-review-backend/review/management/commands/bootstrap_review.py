import os
import secrets
from pathlib import Path

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from review.forms import normalized_key, read_csv
from review.models import Grant, Member, StaffProfile, Term
from review.services import create_term


ACCOUNTS = [
    ("lab-admin", "学生管理员", Grant.Role.MANAGER),
    ("wu-min", "吴敏", Grant.Role.TEACHER_WU),
    ("liu-xinggang", "刘馨刚", Grant.Role.TEACHER_LIU),
    ("lab-reviewer", "结算审核人", Grant.Role.REVIEWER),
]


def write_private(path, text):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8-sig") as stream:
        stream.write(text)


class Command(BaseCommand):
    help = "初始化首学期和四个独立账号。凭证仅写入指定的私密文件。"

    def add_arguments(self, parser):
        parser.add_argument("--credentials", type=Path, default=settings.DATA_DIR / "initial-login.txt")
        parser.add_argument("--roster", type=Path, default=settings.BASE_DIR / "roster.csv")
        parser.add_argument("--title", default="2026–2027 学年第一学期")
        parser.add_argument("--slug", default="2026-fall")
        parser.add_argument("--if-needed", action="store_true")

    def handle(self, *args, **options):
        path = options["credentials"]
        user_model = get_user_model()
        if Term.objects.exists():
            if options["if_needed"]:
                return
            raise CommandError("数据库已经初始化。")
        try:
            rows = read_csv(options["roster"].read_text(encoding="utf-8-sig"), ("姓名",), optional=("登录名",))
        except (OSError, ValueError) as exc:
            raise CommandError(str(exc)) from exc
        names = [(row["姓名"], row.get("登录名") or row["姓名"]) for _, row in rows]
        keys = [normalized_key(login_name) for _, login_name in names]
        if not (2 <= len(names) <= 500 and len(keys) == len(set(keys)) and all(0 < len(key) <= 100 for key in keys)
                and all(0 < len(name) <= 60 and 0 < len(alias) <= 60 for name, alias in names)):
            raise CommandError("初始名单的姓名或登录名无效、重复，或人数超出范围。")
        if not options["title"].strip() or len(options["title"]) > 80:
            raise CommandError("请填写有效的学期名称。")
        from django.core.validators import validate_slug
        from django.core.exceptions import ValidationError

        try:
            validate_slug(options["slug"])
        except ValidationError as exc:
            raise CommandError("请填写有效的学期标识。") from exc
        if len(options["slug"]) > 60:
            raise CommandError("学期标识最长 60 个字符。")
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            raise CommandError("凭证文件已存在，请保管好后选择一个新的输出路径。")
        password = secrets.token_urlsafe(12)
        generated = [(username, name, role, secrets.token_urlsafe(18)) for username, name, role in ACCOUNTS]
        created_file = False
        try:
            with transaction.atomic():
                users = {}
                for username, name, role, secret in generated:
                    user = user_model.objects.create_user(username=username, password=secret, first_name=name)
                    StaffProfile.objects.create(user=user)
                    users[role] = user
                term = create_term(users[Grant.Role.MANAGER], {
                    "title": options["title"], "slug": options["slug"], "password": password,
                })
                Grant.objects.bulk_create([Grant(term=term, user=user, role=role) for role, user in users.items()])
                Member.objects.bulk_create([Member(term=term, name=name, login_name=alias, login_key=key)
                                            for (name, alias), key in zip(names, keys, strict=True)])
                lines = [
                    "课题组学期综合评价系统｜首次登录交接",
                    "仅交给课题组负责人。请分别发给本人，勿发送整份凭证。工作台账号首次登录须修改临时密码。",
                    "",
                ]
                for username, name, _, secret in generated:
                    lines.extend([name, f"账号  {username}", f"临时密码  {secret}", ""])
                lines.extend([
                    f"学生统一口令  {password}",
                    "开启互评后，学生用姓名和上面的统一口令登录。",
                    "完成交接后，请妥善保管或移除此文件。",
                    "",
                ])
                write_private(path, "\n".join(lines))
                created_file = True
        except Exception:
            if created_file:
                path.unlink(missing_ok=True)
            raise
        self.stdout.write(f"已初始化 {len(names)} 名学生与 4 个工作台账号。凭证已写入私密文件。")
