from fractions import Fraction


GRADES = {"A": 5, "B": 4, "C": 3, "D": 2}
AWARDS = {1: ("一等奖", 1500), 2: ("二等奖", 1000), 3: ("三等奖", 500)}
DEFAULT_RULE = {
    "mode": "caps",
    "base": "60",
    "caps": {"teacher": "25", "peer": "15", "attendance": "10", "affairs": "10"},
    "shares": {"teacher": "41.6667", "peer": "25", "attendance": "16.6667", "affairs": "16.6667"},
    "weights": {"wu": "60", "liu": "40"},
    "affair_points": {"leader": "3", "purchase": "5", "activity": "2"},
    "paper_points": {"1": "10", "2": "5", "3": "3"},
}


def rounded_integer(value):
    value = Fraction(value)
    quotient, remainder = divmod(value.numerator, value.denominator)
    return quotient + (2 * remainder >= value.denominator)


def cents(value):
    return rounded_integer(value * 100)


def score_text(value):
    whole, remainder = divmod(cents(value), 100)
    return f"{whole}.{remainder:02d}"


def peer_score(counts, cap):
    valid = sum(counts.values())
    if valid == 0:
        return None
    weighted = sum(GRADES[grade] * count for grade, count in counts.items())
    return Fraction(cap) * Fraction(weighted, 5 * valid)


def group_peer_display(counts, cap):
    total = sum(counts.values())
    if not total:
        return None
    return {
        "score": score_text(peer_score(counts, cap)),
        "bands": {grade: 10 * rounded_integer(Fraction(10 * count, total))
                  for grade, count in counts.items()},
    }


def teacher_score(rule, scores):
    return Fraction(rule["caps"]["teacher"]) / 25 * sum(
        Fraction(rule["weights"][slot]) / 100 * Fraction(score)
        for slot, score in scores.items()
    )


def evaluate(rule, source):
    teacher = teacher_score(rule, source["teacher_scores"])
    peer = peer_score(source["votes"], rule["caps"]["peer"])
    attendance = Fraction(source["attendance"])
    uncapped = sum((Fraction(rule["affair_points"][kind]) for kind in source["affairs"]), Fraction())
    affairs = min(Fraction(rule["caps"]["affairs"]), uncapped)
    papers = sum((Fraction(rule["paper_points"].get(str(position), "0"))
                  for position in source["paper_positions"]), Fraction())
    base = teacher + peer + attendance + affairs
    total = base + papers
    contribution = teacher + peer + affairs
    return {
        "teacher": score_text(teacher), "peer": score_text(peer),
        "attendance": score_text(attendance), "affairs": score_text(affairs),
        "uncapped_affairs": score_text(uncapped), "papers": score_text(papers),
        "base": score_text(base), "total": score_text(total),
        "contribution": score_text(contribution),
        "sort_key": (cents(total), contribution, teacher, peer),
    }


def rank_rows(rows):
    ordered = sorted(rows, key=lambda row: row["sort_key"], reverse=True)
    previous = None
    for index, row in enumerate(ordered, 1):
        if row["sort_key"] != previous:
            rank = index
        row["rank"] = rank
        previous = row.pop("sort_key")
    return ordered


def award_groups(rows):
    return {rank: [row for row in rows if row["rank"] == rank] for rank in AWARDS}
