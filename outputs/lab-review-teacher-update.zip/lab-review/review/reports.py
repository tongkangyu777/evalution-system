import csv

from django.http import Http404, HttpResponse
from django.shortcuts import render
from django.views.decorators.http import require_safe

from .models import Affair, Grant, Paper
from .scoring import GRADES, group_peer_display
from .security import term_permission


def is_submitted(member):
    state = getattr(member, "submission", None)
    return state is not None and state.submitted


@term_permission(Grant.Role.MANAGER)
@require_safe
def progress(request, term, grant):
    submitted, pending = [], []
    counts = dict.fromkeys(GRADES, 0)
    for member in term.members.select_related("submission", "peer"):
        (submitted if is_submitted(member) else pending).append(member.label)
        totals = getattr(member, "peer", None)
        if totals is not None:
            for grade in GRADES:
                counts[grade] += getattr(totals, grade.lower())
    cap = term.rule.settings["caps"]["peer"]
    return render(request, "review/progress.html", {
        "term": term, "submitted": submitted, "pending": pending, "total": len(submitted) + len(pending),
        "display": group_peer_display(counts, cap), "cap": cap,
    })


def progress_export(term):
    for member in term.members.select_related("submission"):
        yield member.name, member.login_name, "已提交" if is_submitted(member) else "未提交"


def attendance_export(term):
    for member in term.members.select_related("attendance"):
        entry = getattr(member, "attendance", None)
        yield member.name, member.login_name, entry.score if entry else None, entry.evidence if entry else None


def affairs_export(term):
    entries = Affair.objects.filter(member__term=term).select_related("member").order_by("member_id", "pk")
    for entry in entries:
        yield entry.member.name, entry.member.login_name, entry.get_kind_display(), entry.reference, entry.evidence


def papers_export(term):
    entries = Paper.objects.filter(member__term=term).select_related("member").order_by("member_id", "pk")
    for entry in entries:
        position = {None: "待导师认定", 0: "认定不计分"}.get(entry.position, entry.position)
        yield (entry.member.name, entry.member.login_name, entry.identifier, entry.published_on,
               position, "是" if entry.special else "否", entry.evidence)


EXPORTS = {
    "progress": (("姓名", "登录名", "提交状态"), progress_export),
    "attendance": (("姓名", "登录名", "考勤分", "核定依据"), attendance_export),
    "affairs": (("姓名", "登录名", "事项类别", "事项标识", "核定依据"), affairs_export),
    "papers": (("姓名", "登录名", "论文标识", "发表日期", "作者顺位", "特殊排序", "论文证明"), papers_export),
}


def csv_cell(value):
    if isinstance(value, str) and (
        value.startswith(("\t", "\r", "\n"))
        or value.lstrip(" \t\r\n\ufeff").startswith(("=", "+", "-", "@", "＝", "＋", "－", "＠"))
    ):
        return "'" + value
    return value


@term_permission(Grant.Role.MANAGER)
@require_safe
def export_csv(request, term, grant, kind):
    if kind not in EXPORTS:
        raise Http404
    headers, rows = EXPORTS[kind]
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{term.slug}-{kind}.csv"'
    response.write("\ufeff")
    writer = csv.writer(response)
    writer.writerow(headers)
    writer.writerows(tuple(csv_cell(cell) for cell in row) for row in rows(term))
    return response
