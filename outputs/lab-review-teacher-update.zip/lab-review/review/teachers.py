import json

from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.crypto import constant_time_compare, salted_hmac
from django.views.decorators.http import require_http_methods, require_POST, require_safe

from .forms import PaperDecisionForm, TeacherScoreForm
from .models import Paper, TeacherScore, Term
from .scoring import GRADES, group_peer_display, peer_score, score_text, teacher_score
from .security import term_permission
from .services import RuleError, audit, editable_records, lock_term, mark_check, persist_deadline
from .staff import TEACHERS


def own_scores(term, role):
    return {record.member_id: record for record in
            TeacherScore.objects.filter(member__term=term, slot=role).order_by("member_id")}


def stamp(term, role, scores):
    snapshot = json.dumps([term.pk, role, [(pk, str(record.score)) for pk, record in scores.items()]])
    return salted_hmac("teacher-form", snapshot, algorithm="sha256").hexdigest()


@term_permission(*TEACHERS)
@require_http_methods(["GET", "POST"])
def teacher_scores(request, term, grant):
    data = request.POST if request.method == "POST" else None
    current = own_scores(term, grant.role)
    rows = []
    for member in term.members.all():
        record = current.get(member.pk)
        prefix = f"s{member.pk}"
        should_validate = data is not None and (record is not None or data.get(f"{prefix}-score"))
        form = TeacherScoreForm(data if should_validate else None, prefix=prefix, use_required_attribute=False,
                                initial={"score": record.score} if record else None)
        rows.append((member, form, should_validate))
    if data is not None:
        valid = all([form.is_valid() for _, form, required in rows if required])
        if valid:
            try:
                with transaction.atomic():
                    locked = lock_term(term.pk)
                    persist_deadline(locked)
                    if locked.state not in (Term.State.OPEN, Term.State.CLOSED):
                        raise RuleError("当前阶段无法录入或修改教师分数。")
                    latest = own_scores(locked, grant.role)
                    if not constant_time_compare(data.get("stamp", ""), stamp(locked, grant.role, latest)):
                        raise RuleError("评分已在其他页面更新。请刷新页面后重试。")
                    changed = 0
                    for member, form, required in rows:
                        if not required:
                            continue
                        record = latest.get(member.pk)
                        if record and record.score == form.cleaned_data["score"]:
                            continue
                        TeacherScore.objects.update_or_create(member=member, slot=grant.role, defaults=form.cleaned_data)
                        changed += 1
                    if changed:
                        audit(locked, request.user, "更新教师评分", count=changed)
            except RuleError as exc:
                messages.error(request, str(exc))
            else:
                messages.success(request, "本人的评分已保存。")
                return redirect("teacher_scores", slug=term.slug)
    return render(request, "review/teacher.html", {
        "term": term, "grant": grant, "rows": [(member, form) for member, form, _ in rows],
        "stamp": stamp(term, grant.role, current), "scored": len(current),
        "editable": term.state in (Term.State.OPEN, Term.State.CLOSED),
        "papers": Paper.objects.filter(member__term=term, special=True).select_related("member"),
        "decision_editable": term.state == Term.State.CLOSED or (term.state == Term.State.OPEN and term.deadline_passed),
    })


@term_permission(*TEACHERS)
@require_safe
def teacher_results(request, term, grant):
    rule = term.rule.settings
    cap = rule["caps"]["peer"]
    scores_by_member = {}
    scores = TeacherScore.objects.filter(member__term=term).values_list("member_id", "slot", "score")
    for member_id, slot, score in scores:
        scores_by_member.setdefault(member_id, {})[slot] = score
    rows = []
    pooled = dict.fromkeys(GRADES, 0)
    for member in term.members.select_related("peer"):
        scores = scores_by_member.get(member.pk, {})
        totals = getattr(member, "peer", None)
        counts = {grade: getattr(totals, grade.lower(), 0) for grade in GRADES}
        for grade, count in counts.items():
            pooled[grade] += count
        weighted = teacher_score(rule, scores) if scores else None
        peer = peer_score(counts, cap)
        available = [score for score in (weighted, peer) if score is not None]
        rows.append({
            "name": member.label,
            "wu": score_text(scores["wu"]) if "wu" in scores else "未填写",
            "liu": score_text(scores["liu"]) if "liu" in scores else "未填写",
            "weighted": score_text(weighted) if weighted is not None else "未填写",
            "peer": score_text(peer) if peer is not None else "暂无有效互评",
            "subtotal": score_text(sum(available)) if available else "待录入",
        })
    return render(request, "review/teacher_results.html", {
        "term": term, "rows": rows, "weights": rule["weights"],
        "display": group_peer_display(pooled, cap), "cap": cap,
        "refresh": term.state in (Term.State.OPEN, Term.State.CLOSED),
    })


@term_permission(*TEACHERS)
@require_POST
def teacher_paper(request, term, grant, paper_id):
    form = PaperDecisionForm(request.POST)
    if not form.is_valid():
        messages.error(request, "请选择认定结果，并填写指导教师统一认定的依据。")
    else:
        try:
            with transaction.atomic():
                locked = lock_term(term.pk)
                editable_records(locked)
                paper = get_object_or_404(Paper, pk=paper_id, member__term=locked, special=True)
                paper.position = int(form.cleaned_data["position"])
                paper.decision = form.cleaned_data["decision"]
                paper.decided_by = request.user
                paper.save(update_fields=["position", "decision", "decided_by"])
                mark_check(paper.member, "papers_checked", False)
                audit(locked, request.user, "导师认定特殊作者排序", member=paper.member_id,
                      paper=paper.pk, position=paper.position)
        except RuleError as exc:
            messages.error(request, str(exc))
        else:
            messages.success(request, "导师认定已保存。请通知录入负责人重新核实该学生论文。")
    return redirect("teacher_scores", slug=term.slug)
