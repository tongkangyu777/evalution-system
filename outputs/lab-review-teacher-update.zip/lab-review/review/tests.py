import csv
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import date, timedelta
from fractions import Fraction
from io import StringIO
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.db import close_old_connections
from django.test import Client, SimpleTestCase, TestCase, TransactionTestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .forms import RuleForm
from .models import Affair, Attendance, Batch, Grant, Paper, PeerTotal, StaffProfile, SubmissionState, TeacherScore, Term
from .scoring import DEFAULT_RULE, evaluate, peer_score, rank_rows, score_text
from .services import (
    RuleError, change_rule, close_term, create_term, open_term, prepare_settlement, publish, submit_ballot,
)


FAST_PASSWORDS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
SHARED = "example-test-pass"
LOGIN = "example-private-login"


def term_fixture(count=11):
    users = {}
    for role in Grant.Role:
        user = get_user_model().objects.create_user(username=f"fixture-{role.value}", password=LOGIN)
        StaffProfile.objects.create(user=user, must_change_password=False)
        users[role] = user
    manager = users[Grant.Role.MANAGER]
    term = create_term(manager, {"title": "虚构测试学期", "slug": "test-term", "password": SHARED})
    Grant.objects.bulk_create([Grant(term=term, user=user, role=role) for role, user in users.items()])
    members = [term.members.create(name=f"示例学生{i:02}", login_name=f"示例学生{i:02}", login_key=f"示例学生{i:02}")
               for i in range(1, count + 1)]
    return term, users, members


def choices(members, default="D"):
    return {f"grade_{member.pk}": [default] for member in members}


def student_client(term, member):
    client = Client()
    response = client.post(reverse("student_login"), {
        "term": term.slug, "login_name": member.login_name, "password": SHARED,
    })
    if response.status_code != 302:
        raise AssertionError(f"Student login failed with status {response.status_code}")
    return client


class ScoringTests(SimpleTestCase):
    def test_pdf_scores_and_affairs_cap(self):
        source = {
            "teacher_scores": {"wu": "22.50", "liu": "20"},
            "votes": {"A": 2, "B": 1, "C": 1, "D": 0},
            "attendance": "9",
            "affairs": ["leader", "purchase", "activity", "activity"],
            "paper_positions": [1, 1, 2, 3],
        }
        result = evaluate(DEFAULT_RULE, source)
        self.assertEqual([result[key] for key in
                          ("teacher", "peer", "uncapped_affairs", "affairs", "base", "papers", "total")],
                         ["21.50", "12.75", "12.00", "10.00", "53.25", "28.00", "81.25"])
        changed = deepcopy(DEFAULT_RULE)
        changed["caps"]["teacher"] = "30"
        changed["weights"] = {"wu": "75", "liu": "25"}
        self.assertEqual(evaluate(changed, source)["teacher"], "26.25")

    def test_peer_grade_bounds_no_votes_and_rounding(self):
        self.assertEqual(peer_score({"A": 3, "B": 0, "C": 0, "D": 0}, "15"), 15)
        self.assertEqual(peer_score({"A": 0, "B": 0, "C": 0, "D": 3}, "15"), 6)
        self.assertIsNone(peer_score({"A": 0, "B": 0, "C": 0, "D": 0}, "15"))
        self.assertEqual(score_text(Fraction(201, 200)), "1.01")

    def test_each_tiebreak_and_true_ties(self):
        keys = [(100, 4, 1, 1), (100, 5, 1, 1), (100, 5, 2, 1), (100, 5, 2, 2),
                (100, 5, 2, 2), (101, 0, 0, 0)]
        rows = rank_rows([{"id": pk, "sort_key": key} for pk, key in enumerate(keys)])
        self.assertEqual([(row["id"], row["rank"]) for row in rows],
                         [(5, 1), (3, 2), (4, 2), (2, 4), (1, 5), (0, 6)])

    def test_rule_configuration_converts_shares_and_validates_weight_sum(self):
        data = {"mode": "shares", "base": "80", "wu": "60", "liu": "40",
                "leader": "3", "purchase": "5", "activity": "2", "paper1": "10", "paper2": "5",
                "paper3": "3", "reason": "年度调整", "share_teacher": "40", "share_peer": "30",
                "share_attendance": "20", "share_affairs": "10"}
        form = RuleForm(data, rule=DEFAULT_RULE)
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["rule"]["caps"],
                         {"teacher": "32", "peer": "24", "attendance": "16", "affairs": "8"})
        self.assertFalse(RuleForm({**data, "liu": "39"}, rule=DEFAULT_RULE).is_valid())
        self.assertFalse(RuleForm({**data, "share_peer": "31"}, rule=DEFAULT_RULE).is_valid())


@override_settings(PASSWORD_HASHERS=FAST_PASSWORDS)
class WorkflowTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.term, cls.users, cls.members = term_fixture()

    def setUp(self):
        self.manager = self.users[Grant.Role.MANAGER]

    def staff_client(self, role):
        client = Client()
        client.force_login(self.users[role])
        return client

    def url(self, name, *args):
        return reverse(name, args=[self.term.slug, *args])

    def open(self):
        open_term(self.term.pk, self.manager, None)

    def submit(self, member, ballot=None):
        return submit_ballot(self.term.pk, member.pk, self.term.pass_version,
                             choices(self.members) if ballot is None else ballot)

    def test_staff_first_password_change_and_roster_setup(self):
        profile = self.manager.staffprofile
        profile.must_change_password = True
        profile.save()
        response = self.client.post(reverse("staff_login"), {"username": self.manager.username, "password": LOGIN})
        self.assertRedirects(response, reverse("staff_home"), fetch_redirect_response=False)
        self.assertRedirects(self.client.get(reverse("staff_home")), reverse("staff_password"))
        response = self.client.post(reverse("staff_password"), {
            "old_password": LOGIN, "new_password1": "private-staff-example-146", "new_password2": "private-staff-example-146",
        })
        self.assertRedirects(response, reverse("staff_home"))
        self.assertContains(self.client.get(self.url("term_home")), "开启互评")
        self.assertContains(self.client.get(self.url("roster")), self.members[0].name)

    def test_ballot_validation_self_exclusion_and_repeat(self):
        self.open()
        ballot = choices(self.members)
        removed = f"grade_{self.members[-1].pk}"
        for bad in (
            {key: value for key, value in ballot.items() if key != removed},
            {**ballot, "grade_999999": ["D"]},
            {**ballot, removed: ["E"]},
            {**ballot, removed: ["A", "D"]},
            {**ballot, **{key: ["A"] for key in list(ballot)[:4]}},
            {**ballot, **{key: ["B"] for key in list(ballot)[:4]}},
        ):
            with self.assertRaises(RuleError):
                self.submit(self.members[0], bad)
        ballot[f"grade_{self.members[0].pk}"] = ["A"]
        self.assertTrue(self.submit(self.members[0], ballot))
        self.assertFalse(self.submit(self.members[0], ballot))
        self.assertEqual(PeerTotal.objects.get(member=self.members[0]).a, 0)
        self.assertEqual(PeerTotal.objects.get(member=self.members[0]).d, 0)
        self.assertEqual(PeerTotal.objects.get(member=self.members[1]).d, 1)
        self.term.refresh_from_db()
        self.assertEqual(self.term.submitted_count, 1)

    def test_batch_released_only_to_submitters_and_tail_counts(self):
        self.open()
        first = student_client(self.term, self.members[0])
        pending = student_client(self.term, self.members[-1])
        self.assertRedirects(pending.get(reverse("student_summary")), reverse("student_home"))
        self.assertContains(first.get(reverse("ballot")), "自评")
        response = first.post(reverse("ballot"), {key: value[0] for key, value in choices(self.members).items()})
        self.assertRedirects(response, reverse("student_home"))
        self.assertContains(first.get(reverse("student_summary")), "汇总待更新")
        for member in self.members[1:10]:
            self.submit(member)
        self.assertContains(first.get(reverse("student_summary")), "第 2 批")
        self.assertContains(first.get(reverse("student_summary")), "6.00")
        self.submit(self.members[-1])
        self.assertEqual(list(Batch.objects.filter(term=self.term).order_by("number").values_list("submitted_count", flat=True)),
                         [5, 10])
        self.assertEqual(PeerTotal.objects.get(member=self.members[0]).d, 10)
        self.assertNotContains(first.get(reverse("student_summary")), "11 份")

    def test_fifth_submission_is_atomic_with_snapshot(self):
        self.open()
        for member in self.members[:4]:
            self.submit(member)
        with patch("review.services.Batch.objects.create", side_effect=RuntimeError("fixture failure")):
            with self.assertRaises(RuntimeError):
                self.submit(self.members[4])
        self.term.refresh_from_db()
        self.assertEqual(self.term.submitted_count, 4)
        self.assertFalse(SubmissionState.objects.get(member=self.members[4]).submitted)
        self.assertEqual(PeerTotal.objects.get(member=self.members[5]).d, 4)
        self.assertFalse(Batch.objects.filter(term=self.term).exists())
        self.assertTrue(self.submit(self.members[4]))

    def test_deadline_blocks_ballots_and_invalidates_pass_after_rotation(self):
        self.open()
        client = student_client(self.term, self.members[0])
        Term.objects.filter(pk=self.term.pk).update(closes_at=timezone.now() - timedelta(seconds=1))
        with self.assertRaisesMessage(RuleError, "已截止"):
            self.submit(self.members[0])
        self.assertContains(client.get(reverse("student_home")), "互评截止")
        staff = self.staff_client(Grant.Role.MANAGER)
        staff.post(self.url("term_action", "rotate"), {"password": "rotated-example-secret", "reason": "更换口令"})
        self.assertRedirects(client.get(reverse("student_home")), reverse("student_login"))

    def test_csrf_rejects_forged_login(self):
        client = Client(enforce_csrf_checks=True)
        response = client.post(reverse("student_login"), {"term": self.term.slug, "password": SHARED})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(response["Cache-Control"], "no-store")

    def test_csv_preview_confirm_and_idempotency(self):
        staff = self.staff_client(Grant.Role.MANAGER)
        url = self.url("csv_import", "roster")
        invalid = staff.post(url, {"data": "姓名,登录名\n示例甲,唯一\n示例乙,唯一"})
        self.assertContains(invalid, "第 3 行")
        self.assertFalse(self.term.members.filter(login_key="唯一").exists())
        for expected_count in (12, 12):
            preview = staff.post(url, {"data": "姓名,登录名\n示例学生额外,唯一"})
            self.assertContains(preview, "导入预览")
            response = staff.post(url, {"action": "confirm", "token": preview.context["token"]})
            self.assertRedirects(response, self.url("roster"))
            self.assertEqual(self.term.members.count(), expected_count)

    def test_rule_versions_and_locking(self):
        revised = deepcopy(DEFAULT_RULE)
        revised["weights"] = {"wu": "55", "liu": "45"}
        second = change_rule(self.term.pk, self.manager, revised, "新一期适用")
        self.assertEqual(second.number, 2)
        self.assertEqual(self.term.versions.get(number=1).settings["weights"], DEFAULT_RULE["weights"])
        self.open()
        with self.assertRaises(RuleError):
            change_rule(self.term.pk, self.manager, DEFAULT_RULE, "不允许")
        staff = self.staff_client(Grant.Role.MANAGER)
        response = staff.post(self.url("term_create"), {"title": "下学期", "slug": "next-term", "password": SHARED})
        self.assertEqual(response.status_code, 302)
        child = Term.objects.get(slug="next-term")
        self.assertEqual(child.rule.settings, revised)
        self.assertEqual(child.members.count(), len(self.members))
        self.assertFalse(child.settlements.exists())

    def test_only_manager_can_access_live_progress_and_exports(self):
        self.open()
        staff = self.staff_client(Grant.Role.MANAGER)
        self.assertEqual(staff.get(self.url("teacher_scores")).status_code, 404)
        self.assertEqual(staff.get(self.url("settlement_view")).status_code, 404)
        self.assertContains(staff.get(self.url("term_home")), "查看进度与汇总")
        progress_url = self.url("term_progress")
        self.assertContains(staff.get(progress_url), "未提交（11 人）")
        teacher = self.staff_client(Grant.Role.TEACHER_WU)
        self.assertEqual(teacher.get(self.url("records")).status_code, 404)
        reviewer = self.staff_client(Grant.Role.REVIEWER)
        self.assertEqual(reviewer.get(self.url("teacher_scores")).status_code, 404)
        student = student_client(self.term, self.members[0])
        for client in (teacher, reviewer, student, Client()):
            self.assertIn(client.get(progress_url).status_code, (302, 404))
            for kind in ("progress", "attendance", "affairs", "papers"):
                self.assertIn(client.get(self.url("term_export", kind)).status_code, (302, 404))
        outside = create_term(self.manager, {"title": "另一学期", "slug": "outside-term", "password": SHARED})
        self.assertEqual(staff.get(reverse("term_progress", args=[outside.slug])).status_code, 404)
        self.assertEqual(staff.get(reverse("term_export", args=[outside.slug, "progress"])).status_code, 404)
        close_term(self.term.pk, self.manager, "到期核实")
        self.assertContains(staff.get(progress_url), "未提交（11 人）")

    def test_staff_group_scores_update_after_each_submission_and_students_keep_batches(self):
        staff = self.staff_client(Grant.Role.MANAGER)
        url = self.url("term_progress")
        draft = staff.get(url)
        self.assertContains(draft, "准备中")
        self.assertNotContains(draft, "data-live-results")
        self.open()
        teacher = self.staff_client(Grant.Role.TEACHER_WU)
        teacher_url = self.url("teacher_results")
        self.submit(self.members[0])
        first = staff.get(url)
        self.assertContains(first, "已提交（1 人）")
        self.assertContains(first, "未提交（10 人）")
        self.assertContains(first, "已纳入 1 份正式提交")
        self.assertContains(first, "6.00")
        self.assertContains(first, "data-live-results")
        self.assertEqual(first.context["pending"], [row.label for row in self.members[1:]])
        teacher_first = teacher.get(teacher_url)
        self.assertEqual(teacher_first.context["display"], first.context["display"])
        self.assertEqual(teacher_first.context["rows"][0]["peer"], "暂无有效互评")
        self.assertEqual(teacher_first.context["rows"][2]["peer"], "6.00")
        student = student_client(self.term, self.members[0])
        self.assertContains(student.get(reverse("student_summary")), "汇总待更新")
        self.submit(self.members[1], choices(self.members, default="C"))
        second = staff.get(url)
        self.assertContains(second, "7.50")
        teacher_second = teacher.get(teacher_url)
        self.assertEqual(teacher_second.context["display"], second.context["display"])
        self.assertEqual(teacher_second.context["rows"][2]["peer"], "7.50")
        for member in self.members[2:5]:
            self.submit(member)
        self.submit(self.members[5], choices(self.members, default="C"))
        sixth = staff.get(url)
        self.assertContains(sixth, "已提交（6 人）")
        self.assertContains(sixth, "已纳入 6 份正式提交")
        self.assertContains(sixth, "7.00")
        self.assertContains(student.get(reverse("student_summary")), "第 1 批 · 累计 5 份")
        close_term(self.term.pk, self.manager, "试用结束")
        self.assertNotContains(staff.get(url), "data-live-results")

    def test_both_teachers_see_saved_scores_but_can_edit_only_their_own(self):
        self.open()
        member = self.members[0]
        self.submit(self.members[1])
        wu = self.staff_client(Grant.Role.TEACHER_WU)
        liu = self.staff_client(Grant.Role.TEACHER_LIU)
        results_url = self.url("teacher_results")
        edit_url = self.url("teacher_scores")
        home = wu.get(self.url("term_home"))
        self.assertContains(home, "独立评分")
        self.assertContains(home, "目前分数结果")
        self.assertNotContains(wu.get(edit_url), "保密备注")

        def save(client, score, **extra):
            stamp = client.get(edit_url).context["stamp"]
            return client.post(edit_url, {"stamp": stamp, f"s{member.pk}-score": score, **extra})

        self.assertEqual(wu.get(results_url).context["rows"][0]["wu"], "未填写")
        self.assertRedirects(save(wu, "22.50", slot="liu"), edit_url)
        current = liu.get(results_url)
        first_row = current.context["rows"][0]
        self.assertEqual((first_row["wu"], first_row["liu"], first_row["weighted"]),
                         ("22.50", "未填写", "13.50"))
        self.assertIsNone(liu.get(edit_url).context["rows"][0][1]["score"].value())
        self.assertEqual((first_row["peer"], first_row["subtotal"]), ("6.00", "19.50"))
        self.assertRedirects(save(liu, "0"), edit_url)
        self.assertEqual(wu.get(results_url).context["rows"][0]["liu"], "0.00")
        self.assertRedirects(save(liu, "20"), edit_url)
        self.assertEqual(wu.get(results_url).context["rows"][0]["weighted"], "21.50")
        close_term(self.term.pk, self.manager, "完成")
        final = wu.get(results_url)
        self.assertEqual(final.context["rows"][0]["peer"], "6.00")
        self.assertEqual(final.context["rows"][0]["subtotal"], "27.50")
        self.assertEqual(final["Cache-Control"], "no-store")
        self.assertEqual(wu.post(results_url, {}).status_code, 405)
        self.assertEqual(self.staff_client(Grant.Role.MANAGER).get(results_url).status_code, 404)
        self.assertEqual(student_client(self.term, member).get(results_url).status_code, 302)

    def test_exports_return_only_requested_records_and_safe_csv(self):
        self.open()
        first, second = self.members[:2]
        self.submit(first)
        Attendance.objects.create(member=first, score="0", evidence="核定为零分")
        Affair.objects.create(member=first, kind=Affair.Kind.LEADER, reference="事项,甲",
                              reference_key="事项,甲", evidence="=1+1")
        Paper.objects.create(member=first, identifier="示例论文", identifier_key="示例论文",
                             published_on=date(2026, 10, 16), special=True,
                             evidence="作者页\n第二页", decision="教师内部核定意见")
        TeacherScore.objects.create(member=first, slot="wu", score="18", note="教师原始保密备注")
        staff = self.staff_client(Grant.Role.MANAGER)

        def read(kind):
            response = staff.get(self.url("term_export", kind))
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response["Cache-Control"], "no-store")
            self.assertIn(f"{self.term.slug}-{kind}.csv", response["Content-Disposition"])
            self.assertTrue(response.content.startswith(b"\xef\xbb\xbf"))
            contents = response.content.decode("utf-8-sig")
            self.assertNotIn("教师原始保密备注", contents)
            self.assertNotIn("教师内部核定意见", contents)
            return list(csv.DictReader(StringIO(contents)))

        progress = read("progress")
        self.assertEqual(progress[0], {"姓名": first.name, "登录名": first.login_name, "提交状态": "已提交"})
        self.assertEqual(progress[1], {"姓名": second.name, "登录名": second.login_name, "提交状态": "未提交"})
        attendance = read("attendance")
        self.assertEqual(attendance[0]["考勤分"], "0.000000")
        self.assertEqual(attendance[1]["考勤分"], "")
        self.assertEqual(read("affairs")[0]["事项标识"], "事项,甲")
        self.assertEqual(read("affairs")[0]["核定依据"], "'=1+1")
        paper = read("papers")[0]
        self.assertEqual(paper["作者顺位"], "待导师认定")
        self.assertEqual(paper["论文证明"], "作者页\n第二页")
        self.assertEqual(staff.get(self.url("term_export", "votes")).status_code, 404)

    def test_zero_votes_and_missing_inputs_block_settlement(self):
        self.open()
        close_term(self.term.pk, self.manager, "到期核实")
        run, issues = prepare_settlement(self.term.pk, self.manager)
        self.assertIsNone(run)
        self.assertIn("无有效他评票", issues[0])
        self.assertIn("考勤未录入", issues[0])

    def test_full_workflow_and_publication_keeps_confidential_fields_private(self):
        staff = self.staff_client(Grant.Role.MANAGER)
        self.assertRedirects(staff.post(self.url("term_action", "open"), {"confirm": "on"}), self.url("term_home"))
        for member in self.members:
            self.submit(member)
        self.assertRedirects(staff.post(self.url("term_action", "close"), {"reason": "已完成"}), self.url("term_home"))
        TeacherScore.objects.create(member=self.members[0], slot="wu", score="9", note="仅吴敏保存的历史保密备注")
        for index, role in enumerate((Grant.Role.TEACHER_WU, Grant.Role.TEACHER_LIU)):
            teacher = self.staff_client(role)
            teacher_url = self.url("teacher_scores")
            page = teacher.get(teacher_url)
            self.assertNotContains(page, "历史保密备注")
            bad_score = teacher.post(teacher_url, {"stamp": page.context["stamp"], f"s{self.members[0].pk}-score": "25.01"})
            self.assertContains(bad_score, "25")
            data = {"stamp": page.context["stamp"], **{f"s{member.pk}-score": str(10 + count + index)
                    for count, member in enumerate(self.members)}}
            if index == 0:
                data[f"s{self.members[0].pk}-note"] = "不接受新增备注"
            self.assertRedirects(teacher.post(teacher_url, data), teacher_url)
            self.assertEqual(TeacherScore.objects.filter(member__term=self.term, slot=role).count(), len(self.members))
        first = self.members[0]
        first_url = self.url("record_item", first.pk)
        bad_attendance = staff.post(first_url, {"action": "attendance", "score": "11", "evidence": "示例考勤"})
        self.assertContains(bad_attendance, "请检查表单中的提示")
        staff.post(first_url, {"action": "affair", "kind": "leader", "reference": "工作编号 A", "evidence": "考核记录"})
        duplicated = staff.post(first_url, {"action": "affair", "kind": "activity", "reference": "工作编号 Ａ", "evidence": "重复"})
        self.assertContains(duplicated, "同一事项已登记")
        paper = {"action": "paper", "identifier": "https://doi.org/10.0000/fixture", "published_on": "2026-10-16",
                 "position": "special", "evidence": "正式发表页"}
        self.assertRedirects(staff.post(first_url, paper), first_url)
        staff.post(first_url, {**paper, "identifier": "doi:10.0000/FIXTURE"})
        self.assertEqual(Paper.objects.filter(member=first).count(), 1)
        check = staff.post(first_url, {"action": "check", "affairs_checked": "on", "papers_checked": "on"})
        self.assertContains(check, "待导师认定")
        exceptional = Paper.objects.get(member=first)
        teacher = self.staff_client(Grant.Role.TEACHER_WU)
        teacher.post(self.url("teacher_paper", exceptional.pk), {"position": "2", "decision": "两位导师统一认定"})
        for member in self.members:
            url = self.url("record_item", member.pk)
            self.assertRedirects(staff.post(url, {"action": "attendance", "score": "0", "evidence": "核定为零分"}), url)
            self.assertRedirects(staff.post(url, {"action": "check", "affairs_checked": "on", "papers_checked": "on"}), url)
        self.assertEqual(Attendance.objects.get(member=first).score, 0)
        self.assertRedirects(staff.post(self.url("term_action", "prepare")), self.url("term_home"))
        reviewer = self.staff_client(Grant.Role.REVIEWER)
        url = self.url("settlement_view")
        private = reviewer.get(url)
        self.assertContains(private, "仅吴敏保存的历史保密备注")
        self.assertNotContains(private, "不接受新增备注")
        self.assertContains(private, "两位导师统一认定")
        run = self.term.settlements.get()
        if any(sum(row["rank"] == rank for row in run.detail) > 1 for rank in (1, 2, 3)):
            self.fail("Fixture unexpectedly tied for an award")
        self.assertRedirects(reviewer.post(url, {"action": "publish", "number": run.number, "confirm": "on"}), url)
        student = student_client(self.term, first)
        public = student.get(reverse("student_results"))
        self.assertContains(public, "综合成绩与获奖名单")
        self.assertContains(public, "1500 元")
        self.assertContains(public, "1000 元")
        self.assertContains(public, "500 元")
        self.assertNotContains(public, "教师原始分")
        self.assertNotContains(public, "历史保密备注")
        self.assertNotContains(public, "正式发表页")
        self.assertEqual(public["Cache-Control"], "no-store")
        self.assertRedirects(reviewer.post(url, {"action": "return", "reason": "准备更正"}), url)
        self.assertContains(student.get(reverse("student_results")), "公示版本 1")

    def test_true_ties_require_audited_award_selection(self):
        self.open()
        close_term(self.term.pk, self.manager, "完成")
        run = self.term.settlements.create(rule=self.term.rule, number=1, detail=[
            {"id": self.members[0].pk, "name": self.members[0].name, "rank": 1, "total": "55.00"},
            {"id": self.members[1].pk, "name": self.members[1].name, "rank": 1, "total": "55.00"},
            {"id": self.members[2].pk, "name": self.members[2].name, "rank": 3, "total": "50.00"},
        ])
        Term.objects.filter(pk=self.term.pk).update(state=Term.State.REVIEW)
        reviewer = self.users[Grant.Role.REVIEWER]
        with self.assertRaisesMessage(RuleError, "仍并列"):
            publish(self.term.pk, reviewer, run.number, {})
        result = publish(self.term.pk, reviewer, run.number, {1: (str(self.members[1].pk), "课题组核实决定")})
        self.assertEqual([row["rank"] for row in result.public], [1, 1, 3])
        self.assertEqual([row["amount"] for row in result.public], [None, 1500, 500])
        self.assertEqual(self.term.audits.order_by("-pk").first().details["tied_awards"]["1"]["reason"],
                         "课题组核实决定")


@override_settings(PASSWORD_HASHERS=FAST_PASSWORDS)
class ConcurrentSubmissionTests(TransactionTestCase):
    def setUp(self):
        self.term, self.users, self.members = term_fixture(6)
        self.manager = self.users[Grant.Role.MANAGER]
        open_term(self.term.pk, self.manager, None)
        self.payload = choices(self.members)

    def submit(self, member_id):
        close_old_connections()
        try:
            return submit_ballot(self.term.pk, member_id, self.term.pass_version, self.payload)
        except RuleError:
            return False
        finally:
            close_old_connections()

    def test_retries_racing_across_fifth_submission(self):
        ids = [member.pk for member in self.members[:5]]
        with ThreadPoolExecutor(max_workers=4) as pool:
            outcomes = list(pool.map(self.submit, [*ids, ids[0], ids[-1]]))
        self.assertEqual(sum(outcomes), 5)
        self.term.refresh_from_db()
        self.assertEqual(self.term.submitted_count, 5)
        self.assertEqual(Batch.objects.get(term=self.term).submitted_count, 5)
        self.assertEqual(PeerTotal.objects.get(member=self.members[-1]).d, 5)

    def test_submission_racing_manual_close_is_consistent(self):
        def close():
            close_old_connections()
            try:
                close_term(self.term.pk, self.manager, "截止并发测试")
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as pool:
            submitted = pool.submit(self.submit, self.members[0].pk)
            closed = pool.submit(close)
            closed.result()
            accepted = submitted.result()
        self.term.refresh_from_db()
        self.assertEqual(self.term.state, Term.State.CLOSED)
        self.assertEqual(self.term.submitted_count, int(accepted))
        self.assertEqual(PeerTotal.objects.get(member=self.members[1]).d, int(accepted))
