from functools import lru_cache
from pathlib import Path

from django.contrib import messages
from django.contrib.auth import login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth.hashers import check_password, make_password
from django.db import transaction
from django.http import FileResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods, require_POST

from .forms import StudentLoginForm, normalized_key
from .models import Grant, Member, StaffProfile, SubmissionState, Term
from .scoring import GRADES
from .security import attempt_key, login_blocked, record_failed_login, student_required
from .services import BallotValidationError, RuleError, submit_ballot


@lru_cache(maxsize=1)
def dummy_password():
    return make_password("invalid-term-placeholder")


@require_http_methods(["GET", "POST"])
def student_login(request):
    if request.method == "GET" and request.session.get("student"):
        return redirect("student_home")
    terms = list(Term.objects.exclude(state=Term.State.DRAFT).order_by("-pk"))
    form = StudentLoginForm(request.POST if request.method == "POST" else None, terms=terms)
    if request.method == "POST":
        key = attempt_key(request, "student")
        if login_blocked(key):
            form.add_error(None, "尝试次数过多，请稍后再试。")
            return render(request, "review/login.html", {"form": form, "student": True, "terms": terms}, status=429)
        if form.is_valid():
            term = next((row for row in terms if row.slug == form.cleaned_data["term"]), None)
            password_ok = check_password(form.cleaned_data["password"], term.shared_hash if term else dummy_password())
            member = None
            if password_ok and term:
                member = term.members.filter(login_key=normalized_key(form.cleaned_data["login_name"])).first()
            if member:
                request.session.flush()
                request.session["student"] = {"term": term.pk, "member": member.pk, "version": term.pass_version}
                return redirect("student_home")
            form.add_error(None, "学期、姓名或口令有误。")
        record_failed_login(key)
    return render(request, "review/login.html", {"form": form, "student": True, "terms": terms})


@require_http_methods(["GET", "POST"])
def staff_login(request):
    if request.method == "GET" and request.user.is_authenticated:
        return redirect("staff_home")
    key = attempt_key(request, "staff")
    if request.method == "POST" and login_blocked(key):
        form = AuthenticationForm(request)
        return render(request, "review/login.html", {"form": form, "blocked": True}, status=429)
    form = AuthenticationForm(request, request.POST if request.method == "POST" else None)
    form.fields["username"].label = "账号"
    if request.method == "POST":
        if form.is_valid():
            user = form.get_user()
            if StaffProfile.objects.filter(user=user).exists() and Grant.objects.filter(user=user).exists():
                request.session.flush()
                login(request, user)
                return redirect("staff_home")
            form.add_error(None, "账号或密码有误。")
        record_failed_login(key)
    return render(request, "review/login.html", {"form": form})


@login_required(login_url="staff_login")
@require_http_methods(["GET", "POST"])
def staff_password(request):
    profile = get_object_or_404(StaffProfile, user=request.user)
    form = PasswordChangeForm(request.user, request.POST if request.method == "POST" else None)
    if request.method == "POST" and form.is_valid():
        if form.cleaned_data["new_password1"] == form.cleaned_data["old_password"]:
            form.add_error("new_password1", "请设置一个不同于原密码的新密码。")
        else:
            with transaction.atomic():
                user = form.save()
                profile.must_change_password = False
                profile.save(update_fields=["must_change_password"])
            update_session_auth_hash(request, user)
            messages.success(request, "密码已更新。")
            return redirect("staff_home")
    return render(request, "review/form.html", {
        "title": "修改密码", "form": form, "button": "保存新密码",
        "intro": "首次登录请先修改临时密码。" if profile.must_change_password else "",
    })


@require_POST
def sign_out(request):
    logout(request)
    return redirect("student_login")


def has_submitted(member):
    return SubmissionState.objects.filter(member=member, submitted=True).exists()


@student_required
def student_home(request, member):
    return render(request, "review/student_home.html", {
        "member": member, "term": member.term, "submitted": has_submitted(member),
        "published": member.term.settlements.filter(published_at__isnull=False).exists(),
    })


@student_required
@require_http_methods(["GET", "POST"])
def ballot(request, member):
    term = member.term
    if has_submitted(member):
        return redirect("student_home")
    if request.method == "GET" and not term.accepts_ballots:
        messages.error(request, "本学期互评已截止。")
        return redirect("student_home")
    choices = {}
    errors = []
    if request.method == "POST":
        choices = {key: values for key, values in request.POST.lists() if key != "csrfmiddlewaretoken"}
        try:
            submit_ballot(term.pk, member.pk, request.session["student"]["version"], choices)
        except BallotValidationError as exc:
            errors = exc.reasons
        except RuleError as exc:
            errors = [str(exc)]
        else:
            messages.success(request, "互评已提交。")
            return redirect("student_home")
    rows = []
    for candidate in term.members.all():
        values = choices.get(f"grade_{candidate.pk}", [])
        picked = values[0] if len(values) == 1 and values[0] in GRADES else ""
        rows.append((candidate, picked))
    return render(request, "review/ballot.html", {
        "term": term, "member": member, "rows": rows, "grades": GRADES, "ballot_errors": errors,
    })


@student_required
def student_summary(request, member):
    if not has_submitted(member):
        messages.info(request, "请先完成互评，再查看分批汇总。")
        return redirect("student_home")
    batch = member.term.batches.order_by("-number").first()
    return render(request, "review/summary.html", {
        "term": member.term, "batch": batch, "cap": member.term.rule.settings["caps"]["peer"],
    })


@student_required
def student_results(request, member):
    publication = (member.term.settlements.filter(published_at__isnull=False)
                   .values("number", "published_at", "public").order_by("-number").first())
    return render(request, "review/results.html", {"term": member.term, "publication": publication})


def css(request):
    return asset("style.css", "text/css; charset=utf-8")


def javascript(request):
    return asset("app.js", "text/javascript; charset=utf-8")


def asset(name, mime):
    path = Path(__file__).resolve().parent / "assets" / name
    response = FileResponse(path.open("rb"), content_type=mime)
    response.headers["Cache-Control"] = "public, max-age=300"
    return response


def error_page(request, status, title, explanation):
    return render(request, "review/error.html", {"title": title, "explanation": explanation}, status=status)


def csrf_failure(request, reason=""):
    return error_page(request, 403, "页面已失效", "请返回入口重新登录或刷新页面后再提交。")


def bad_request(request, exception):
    return error_page(request, 400, "请求无法处理", "请核对填写内容后重试。")


def forbidden(request, exception):
    return error_page(request, 403, "没有访问权限", "请使用获授权的账号。")


def missing(request, exception):
    return error_page(request, 404, "页面未找到", "请从系统入口重新进入。")


def server_error(request):
    return error_page(request, 500, "暂时无法处理", "请稍后重试。提交互评前可先查看是否已提交。")
