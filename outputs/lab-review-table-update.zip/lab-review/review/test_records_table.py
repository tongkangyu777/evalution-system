from datetime import date
from decimal import Decimal

from django.test import TestCase, override_settings
from django.urls import reverse

from .models import Attendance, Grant, Paper
from .tests import FAST_PASSWORDS, term_fixture


@override_settings(PASSWORD_HASHERS=FAST_PASSWORDS)
class RecordsTableTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.term, cls.users, cls.members = term_fixture(count=3)

    def setUp(self):
        self.client.force_login(self.users[Grant.Role.MANAGER])
        self.url = reverse("records", args=[self.term.slug])

    def attendance_data(self):
        page = self.client.get(self.url)
        self.assertContains(page, 'id="attendance-batch"')
        return {"action": "save_attendance", "stamp": page.context["stamp"]}

    def attendance_fields(self, member, score, evidence):
        return {f"attendance-{member.pk}-score": score, f"attendance-{member.pk}-evidence": evidence}

    def test_batch_saves_multiple_attendance_rows_and_preserves_blank_rows(self):
        first, second, unused = self.members
        data = {**self.attendance_data(), **self.attendance_fields(first, "9.5", "考勤册第 1 行"),
                **self.attendance_fields(second, "0", "考勤册第 2 行"),
                **self.attendance_fields(unused, "", "")}
        self.assertRedirects(self.client.post(self.url, data), self.url)
        self.assertEqual(Attendance.objects.get(member=first).score, Decimal("9.5"))
        self.assertEqual(Attendance.objects.get(member=second).score, 0)
        self.assertFalse(Attendance.objects.filter(member=unused).exists())

    def test_batch_validation_and_stale_stamp_do_not_overwrite_attendance(self):
        first, second, _ = self.members
        initial = self.attendance_data()
        invalid = {**initial, **self.attendance_fields(first, "5", "考勤册"), **self.attendance_fields(second, "6", "")}
        self.assertContains(self.client.post(self.url, invalid), "请核对表格中的考勤分和依据")
        self.assertFalse(Attendance.objects.filter(member__term=self.term).exists())
        self.client.post(self.url, {**initial, **self.attendance_fields(first, "8", "新考勤册")})
        self.assertContains(self.client.post(self.url, {
            **initial, **self.attendance_fields(first, "5", "旧考勤册"),
        }), "表格中的考勤已更新")
        self.assertEqual(Attendance.objects.get(member=first).score, 8)

    def test_inline_affair_edit_and_special_paper_edit_keep_role_and_verification_rules(self):
        first, second, _ = self.members
        destination = f"{self.url}#member-{first.pk}"
        self.assertRedirects(self.client.post(self.url, {
            "action": "affair", "member": first.pk, "kind": "leader",
            "reference": "事项甲", "evidence": "依据甲",
        }), destination)
        affair = first.affairs.get()
        self.assertRedirects(self.client.post(self.url, {
            "action": "edit_affair", "member": first.pk, "entry": affair.pk, "kind": "activity",
            "reference": "事项甲", "evidence": "修订依据",
        }), destination)
        affair.refresh_from_db()
        self.assertEqual((affair.kind, affair.evidence), ("activity", "修订依据"))
        paper = Paper.objects.create(member=first, identifier="10/example", identifier_key="10/example",
                                     published_on=date(2026, 10, 15), special=True, position=1, evidence="旧证明",
                                     decision="认定", decided_by=self.users[Grant.Role.TEACHER_WU])
        data = {"action": "edit_paper", "member": first.pk, "entry": paper.pk, "identifier": paper.identifier,
                "published_on": "2026-10-15", "position": "special", "evidence": "新证明"}
        self.assertEqual(self.client.post(self.url, {**data, "member": second.pk}).status_code, 404)
        self.assertRedirects(self.client.post(self.url, data), destination)
        paper.refresh_from_db()
        self.assertEqual((paper.evidence, paper.position, paper.decision), ("新证明", None, ""))
        self.assertContains(self.client.post(self.url, {
            "action": "check", "member": first.pk, "papers_checked": "on",
        }), "存在待导师认定的论文")
