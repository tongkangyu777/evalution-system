"use strict";

const liveResults = document.querySelector("[data-live-results]");
if (liveResults) {
  let loading = false;
  const timer = window.setInterval(async () => {
    if (loading || document.visibilityState !== "visible") return;
    loading = true;
    try {
      const response = await fetch(window.location.href, {cache: "no-store"});
      if (response.redirected || [401, 403, 404].includes(response.status)) {
        window.location.reload();
      } else if (response.ok) {
        const page = new DOMParser().parseFromString(await response.text(), "text/html");
        const latest = page.getElementById(liveResults.id);
        if (latest) {
          liveResults.replaceChildren(...latest.childNodes);
          if (!latest.hasAttribute("data-live-results")) window.clearInterval(timer);
        }
      }
    } catch {
      // Try again on the next interval if the connection drops.
    } finally {
      loading = false;
    }
  }, 5000);
}

const ballot = document.getElementById("ballot");
if (ballot) {
  const dialog = document.getElementById("ballot-confirm");
  const confirm = document.getElementById("ballot-send");
  const error = document.getElementById("ballot-error");
  const failure = document.getElementById("ballot-failure");
  const reasonsList = document.getElementById("ballot-failure-reasons");
  const rows = Array.from(ballot.querySelectorAll(".ballot-row"));
  let correction = null;
  let sending = false;
  ballot.noValidate = true;

  const counts = () => {
    const selected = Array.from(ballot.querySelectorAll("input[type=radio]:checked"));
    return {
      filled: selected.length,
      a: selected.filter((field) => field.value === "A").length,
      b: selected.filter((field) => field.value === "B").length,
    };
  };

  const refresh = () => {
    const current = counts();
    document.getElementById("filled").textContent = current.filled;
    document.getElementById("remaining-a").textContent = 3 - current.a;
    document.getElementById("remaining-b").textContent = 3 - current.b;
    error.hidden = current.a <= 3 && current.b <= 3;
    error.textContent = error.hidden ? "" : "A 和 B 各最多选择 3 人，请调整后再提交。";
  };

  ballot.addEventListener("change", refresh);
  refresh();
  window.addEventListener("beforeunload", (event) => {
    if (counts().filled && !sending) {
      event.preventDefault();
      event.returnValue = "";
    }
  });

  ballot.addEventListener("submit", (event) => {
    const current = counts();
    const missing = rows.filter((row) => !row.querySelector("input:checked"));
    const reasons = [];
    if (current.a > 3) reasons.push(`A 最多选 3 人，已选 ${current.a} 人。`);
    if (current.b > 3) reasons.push(`B 最多选 3 人，已选 ${current.b} 人。`);
    if (missing.length) reasons.push(`未填写：${missing.map((row) => row.dataset.candidate).join("、")}`);
    if (reasons.length) {
      event.preventDefault();
      const firstExtra = ballot.querySelectorAll(`input[value="${current.a > 3 ? "A" : "B"}"]:checked`)[3];
      correction = missing[0] || firstExtra?.closest(".ballot-row");
      reasonsList.replaceChildren(...reasons.map((reason) => {
        const item = document.createElement("li");
        item.textContent = reason;
        return item;
      }));
      if (dialog.open) dialog.close();
      failure.showModal();
      return;
    }
    if (dialog.open && event.submitter === confirm) {
      sending = true;
      confirm.disabled = true;
      return;
    }
    event.preventDefault();
    document.getElementById("ballot-review").textContent =
      `已评价 ${current.filled} / ${rows.length} 人。A 已选 ${current.a} 人，B 已选 ${current.b} 人。`;
    dialog.showModal();
  });
  document.getElementById("ballot-cancel").addEventListener("click", () => dialog.close());
  document.getElementById("ballot-failure-close").addEventListener("click", () => failure.close());
  failure.addEventListener("close", () => {
    if (correction) {
      correction.scrollIntoView({block: "center"});
      const field = correction.querySelector("input:checked") || correction.querySelector("input");
      field.focus({preventScroll: true});
    }
  });
  if (reasonsList.children.length) failure.showModal();
}

const rule = document.getElementById("rule-form");
if (rule) {
  const mode = rule.querySelector("[name=mode]");
  const refresh = () => {
    const useShares = mode.value === "shares";
    for (const field of rule.querySelectorAll("[name=base], [name^=share_], [name^=cap_]")) {
      const inUse = field.name.startsWith("cap_") ? !useShares : useShares;
      field.closest("p").hidden = !inUse;
      field.disabled = !inUse;
    }
  };
  mode.addEventListener("change", refresh);
  refresh();
}

const teacherForm = document.getElementById("teacher-score-form");
if (teacherForm) {
  const dialog = document.getElementById("teacher-missing-dialog");
  const list = document.getElementById("teacher-missing-list");
  const fields = Array.from(teacherForm.querySelectorAll("fieldset[data-student] input[type=number]"));
  const missingFields = () => fields.filter((field) => !field.value.trim());
  teacherForm.addEventListener("submit", (event) => {
    if (event.submitter?.value !== "submit") return;
    const missing = missingFields();
    if (!missing.length) return;
    event.preventDefault();
    const names = missing.map((field) => {
      const item = document.createElement("li");
      item.textContent = field.closest("[data-student]").dataset.student;
      return item;
    });
    list.replaceChildren(...names);
    dialog.showModal();
  });
  document.getElementById("teacher-missing-close").addEventListener("click", () => {
    dialog.close();
    missingFields()[0]?.focus();
  });
  if (list.children.length) dialog.showModal();
}
