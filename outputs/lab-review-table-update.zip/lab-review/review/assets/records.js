"use strict";

const recordForms = [...document.querySelectorAll("[data-record-edit]")];
const recordDrafts = new Map(recordForms.map((form) => [form, JSON.stringify([...new FormData(form)])]));
let submittingRecord = null;

for (const form of recordForms) {
  form.addEventListener("submit", () => { submittingRecord = form; });
}

window.addEventListener("beforeunload", (event) => {
  const hasUnsavedDraft = recordForms.some((form) =>
    form !== submittingRecord && JSON.stringify([...new FormData(form)]) !== recordDrafts.get(form)
  );
  submittingRecord = null;
  if (hasUnsavedDraft) {
    event.preventDefault();
    event.returnValue = "";
  }
});
