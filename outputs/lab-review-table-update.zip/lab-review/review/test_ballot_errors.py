from django.test import TestCase, override_settings
from django.urls import reverse

from .models import Grant, SubmissionState
from .services import close_term, open_term
from .tests import FAST_PASSWORDS, student_client, term_fixture


@override_settings(PASSWORD_HASHERS=FAST_PASSWORDS)
class BallotErrorsTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.term, cls.users, cls.members = term_fixture()

    def setUp(self):
        self.manager = self.users[Grant.Role.MANAGER]
        open_term(self.term.pk, self.manager, None)
        self.student = self.members[0]
        self.client = student_client(self.term, self.student)
        self.url = reverse("ballot")

    def test_invalid_submission_lists_all_problems_and_retains_valid_choices(self):
        payload = {f"grade_{member.pk}": "A" for member in self.members[:4]}
        payload.update({f"grade_{member.pk}": "B" for member in self.members[4:8]})
        invalid = self.members[8]
        missing = "、".join(member.label for member in self.members[9:])
        payload[f"grade_{invalid.pk}"] = ["C", "D"]
        payload["grade_999999"] = "D"

        response = self.client.post(self.url, payload)

        self.assertContains(response, 'id="ballot-failure"')
        self.assertEqual(response.context["ballot_errors"], [
            "A 最多选 3 人，已选 4 人。",
            "B 最多选 3 人，已选 4 人。",
            f"未填写：{missing}",
            f"请重新选择一个有效等级：{invalid.label}",
            "表单包含名单外的选项，请检查后重新提交。",
        ])
        self.assertEqual([picked for _, picked in response.context["rows"]], ["A"] * 4 + ["B"] * 4 + [""] * 3)
        self.assertFalse(SubmissionState.objects.get(member=self.student).submitted)
        self.term.refresh_from_db()
        self.assertEqual(self.term.submitted_count, 0)

    def test_deadline_rejection_is_displayed_as_ballot_error(self):
        close_term(self.term.pk, self.manager, "试用结束")
        response = self.client.post(self.url, {f"grade_{self.student.pk}": "C"})

        self.assertEqual(response.context["ballot_errors"], ["本学期互评已截止。"])
        self.assertEqual(response.context["rows"][0][1], "C")
        self.assertNotContains(response, "检查并提交")
