import csv

from django.http import Http404, HttpResponse
from django.shortcuts import render
from django.views.decorators.http import require_safe

from .models import Affair, Grant, Paper
from .security import term_permission


def submission_rows(term):
    return [
        (member, bool(getattr(getattr(member, "submission", None), "submitted", False)))
        for member in term.members.select_related("submission")
    ]


@term_permission(Grant.Role.MANAGER)
@require_safe
def progress(request, term, grant):
    submitted, pending = [], []
    for member, finished in submission_rows(term):
        (submitted if finished else pending).append(member)
    count = len(submitted)
    # Keep the batch at or before the count observed in the roster query.
    batch = term.batches.filter(submitted_count__lte=count).order_by("-number").first()
    return render(request, "review/progress.html", {
        "term": term, "submitted": submitted, "pending": pending, "total": count + len(pending),
        "batch": batch, "cap": term.rule.settings["caps"]["peer"],
    })


def progress_export(term):
    for member, finished in submission_rows(term):
        yield member.name, member.login_name, "已提交" if finished else "未提交"


def attendance_export(term):
    for member in term.members.select_related("attendance"):
        entry = getattr(member, "attendance", None)
        yield member.name, member.login_name, entry.score if entry else None, entry.evidence if entry else None


def affairs_export(term):
    entries = Affair.objects.filter(member__term=term).select_related("member").order_by("member_id", "pk")
    for entry in entries:
        yield entry.member.name, entry.member.login_name, entry.get_kind_display(), entry.reference, entry.evidence


def papers_export(term):
    entries = Paper.objects.filter(member__term=term).select_related("member").order_by("member_id", "pk")
    for entry in entries:
        position = {None: "待导师认定", 0: "认定不计分"}.get(entry.position, entry.position)
        yield (entry.member.name, entry.member.login_name, entry.identifier, entry.published_on,
               position, "是" if entry.special else "否", entry.evidence)


EXPORTS = {
    "progress": (("姓名", "登录名", "提交状态"), progress_export),
    "attendance": (("姓名", "登录名", "考勤分", "核定依据"), attendance_export),
    "affairs": (("姓名", "登录名", "事项类别", "事项标识", "核定依据"), affairs_export),
    "papers": (("姓名", "登录名", "论文标识", "发表日期", "作者顺位", "特殊排序", "论文证明"), papers_export),
}


def csv_cell(value):
    if isinstance(value, str) and (
        value.startswith(("\t", "\r", "\n"))
        or value.lstrip(" \t\r\n\ufeff").startswith(("=", "+", "-", "@", "＝", "＋", "－", "＠"))
    ):
        return "'" + value
    return value


@term_permission(Grant.Role.MANAGER)
@require_safe
def export_csv(request, term, grant, kind):
    if kind not in EXPORTS:
        raise Http404
    headers, rows = EXPORTS[kind]
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{term.slug}-{kind}.csv"'
    response.write("\ufeff")
    writer = csv.writer(response)
    writer.writerow(headers)
    writer.writerows(tuple(csv_cell(cell) for cell in row) for row in rows(term))
    return response
