from django.contrib import messages
from django import forms
from django.db import IntegrityError, transaction
from django.shortcuts import redirect, render
from django.views.decorators.http import require_http_methods

from .forms import CATEGORIES, OpenForm, ReasonForm, RotateForm, RuleForm, TermForm
from .models import Grant, Term
from .scoring import AWARDS, award_groups
from .security import staff_required, term_permission
from .services import (
    RuleError, audit, change_rule, close_term, create_term, lock_term, open_term, prepare_settlement,
    publish, return_for_correction, rotate_pass,
)


MANAGER = Grant.Role.MANAGER
REVIEWER = Grant.Role.REVIEWER
TEACHERS = (Grant.Role.TEACHER_WU, Grant.Role.TEACHER_LIU)


class RenameForm(forms.Form):
    title = forms.CharField(label="学期名称", max_length=80)


@staff_required
def staff_home(request):
    grants = request.user.term_grants.select_related("term").order_by("-term_id")
    return render(request, "review/staff_home.html", {"grants": grants})


@term_permission(*Grant.Role.values)
def term_home(request, term, grant):
    context = {"term": term, "grant": grant, "count": term.members.count()}
    if grant.role == MANAGER:
        context.update({
            "open_form": OpenForm(), "close_form": ReasonForm(auto_id="id_close_%s"),
            "rotate_form": RotateForm(auto_id="id_rotate_%s"),
            "pending": term.members.count() - term.submitted_count,
            "audits": term.audits.select_related("actor").order_by("-pk")[:20],
        })
    return render(request, "review/term.html", context)


@term_permission(MANAGER)
@require_http_methods(["GET", "POST"])
def term_rename(request, term, grant):
    form = RenameForm(request.POST if request.method == "POST" else None, initial={"title": term.title})
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            locked = lock_term(term.pk)
            if locked.state != Term.State.DRAFT:
                form.add_error(None, "只能在准备阶段修改学期名称。")
            else:
                new_title = form.cleaned_data["title"]
                audit(locked, request.user, "修改学期名称", before=locked.title, after=new_title)
                locked.title = new_title
                locked.save(update_fields=["title"])
                return redirect("term_home", slug=term.slug)
    return render(request, "review/form.html", {
        "term": term, "title": "修改学期名称", "form": form, "button": "保存名称",
    })


@term_permission(MANAGER)
@require_http_methods(["GET", "POST"])
def term_create(request, term, grant):
    form = TermForm(request.POST if request.method == "POST" else None)
    if request.method == "POST" and form.is_valid():
        try:
            created = create_term(request.user, form.cleaned_data, source=term)
        except (RuleError, IntegrityError):
            form.add_error("slug", "学期标识已被使用。")
        else:
            messages.success(request, "新学期已创建，名单、角色和评分规则已复制。")
            return redirect("term_home", slug=created.slug)
    return render(request, "review/form.html", {
        "term": term, "title": "创建下一学期", "form": form, "button": "创建学期",
        "intro": "复制当前名单、角色和规则。新学期使用独立口令，成绩和投票记录从空白开始。",
    })


@term_permission(MANAGER)
@require_http_methods(["GET", "POST"])
def term_rule(request, term, grant):
    form = RuleForm(request.POST if request.method == "POST" else None, rule=term.rule.settings)
    candidate = None
    if request.method == "POST" and form.is_valid():
        candidate = form.cleaned_data["rule"]
        if request.POST.get("action") == "save":
            try:
                saved = change_rule(term.pk, request.user, candidate, form.cleaned_data["reason"])
            except RuleError as exc:
                form.add_error(None, str(exc))
            else:
                messages.success(request, f"当前规则版本 v{saved.number}。")
                return redirect("term_rule", slug=term.slug)
    active = candidate or term.rule.settings
    return render(request, "review/rules.html", {
        "term": term, "form": form, "active": active, "candidate": candidate,
        "categories": [(label, active["caps"][key], active["shares"][key]) for key, label in CATEGORIES.items()],
        "versions": term.versions.select_related("editor").order_by("-number"),
    })


@term_permission(MANAGER)
@require_http_methods(["POST"])
def term_action(request, term, grant, action):
    if action == "prepare":
        try:
            _, issues = prepare_settlement(term.pk, request.user)
        except RuleError as exc:
            messages.error(request, str(exc))
        else:
            if issues:
                return render(request, "review/issues.html", {"term": term, "issues": issues})
            messages.success(request, "结算已发起，待审核人确认发布。")
        return redirect("term_home", slug=term.slug)
    operations = {
        "open": (OpenForm, open_term, ("closes_at",), "互评已开启。"),
        "close": (ReasonForm, close_term, ("reason",), "互评已截止。"),
        "rotate": (RotateForm, rotate_pass, ("password", "reason"), "口令已轮换，原学生会话已失效。"),
    }
    if action not in operations:
        return render(request, "review/error.html", {"title": "页面未找到"}, status=404)
    form_class, operation, fields, confirmation = operations[action]
    form = form_class(request.POST)
    if form.is_valid():
        try:
            operation(term.pk, request.user, *[form.cleaned_data[key] for key in fields])
        except RuleError as exc:
            form.add_error(None, str(exc))
        else:
            messages.success(request, confirmation)
            return redirect("term_home", slug=term.slug)
    return render(request, "review/form.html", {
        "term": term, "title": "请核对操作", "form": form, "button": "确认",
    })


@term_permission(REVIEWER)
@require_http_methods(["GET", "POST"])
def settlement_view(request, term, grant):
    run = term.settlements.order_by("-number").first()
    form = ReasonForm(request.POST if request.method == "POST" and request.POST.get("action") == "return" else None)
    if request.method == "POST":
        try:
            if request.POST.get("action") == "return" and form.is_valid():
                return_for_correction(term.pk, request.user, form.cleaned_data["reason"])
                messages.success(request, "已退回管理员补录或更正。")
                return redirect("settlement_view", slug=term.slug)
            if request.POST.get("action") == "publish":
                if not run or request.POST.get("number") != str(run.number) or request.POST.get("confirm") != "on":
                    raise RuleError("请核对结算版本并勾选公示确认。")
                choices = {rank: (request.POST.get(f"winner_{rank}", ""), request.POST.get(f"reason_{rank}", "").strip())
                           for rank in AWARDS}
                publish(term.pk, request.user, run.number, choices)
                messages.success(request, "已向本学期成员公示综合成绩、名次和获奖名单。")
                return redirect("settlement_view", slug=term.slug)
        except RuleError as exc:
            messages.error(request, str(exc))
    ties = []
    awards = []
    if run:
        for rank, group in award_groups(run.detail).items():
            title, amount = AWARDS[rank]
            if len(group) > 1:
                ties.append((rank, title, amount, group))
            elif group:
                awards.append((title, amount, group[0]["name"]))
    return render(request, "review/settlement.html", {
        "term": term, "run": run, "ties": ties, "awards": awards, "form": form,
    })
